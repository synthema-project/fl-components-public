import argparse
import os
import sys

import pandas as pd


def run_init(args: argparse.Namespace) -> None:
    """Handler for the 'init' command."""
    # Use the output_dir provided by the CLI parser
    create_structure(output_dir=args.output_dir, template=args.template, use_dp=args.dp)


def create_structure(output_dir: str = ".", template: str = "noop", use_dp: bool = False) -> None:
    """Scaffold a model project directory with MSI template files."""
    import os
    from .templates import (
        get_main_template, get_readme_template, get_pyproject_template,
        get_license_template, get_pytorch_template, get_keras_template, get_sklearn_template
    )
    # Create target directory and the nested src directory
    print(
        f"🏗️ Initialising MSI project structure in '{os.path.abspath(output_dir)}' (Template: {template}, "
        f"DP: {use_dp})...")

    # 1. Create the root project directory
    os.makedirs(output_dir, exist_ok=True)

    # 1. Determine which entry point template to use
    if template == "pytorch":
        example_code = get_pytorch_template(dp=use_dp)
        print("⚠️  NOTE: You selected PyTorch. Ensure you install: pip install model-store-interface[edge]")
    elif template == "keras":
        example_code = get_keras_template(dp=use_dp)
        print("⚠️  NOTE: You selected Keras. Ensure you install: pip install model-store-interface[tf-dp]")
    elif template == "scikit-learn":
        example_code = get_sklearn_template(dp=use_dp)
        print("⚠️  NOTE: You selected Scikit-Learn. Ensure you install: pip install scikit-learn")
    else:
        example_code = get_main_template()

    # 2. Write the core Python execution logic
    with open(os.path.join(output_dir, "example.py"), "w", encoding="utf-8") as f:
        f.write(example_code)

    # 3. Write standard configuration files
    with open(os.path.join(output_dir, "pyproject.toml"), "w", encoding="utf-8") as f:
        f.write(get_pyproject_template())

    with open(os.path.join(output_dir, "LICENSE"), "w", encoding="utf-8") as f:
        f.write(get_license_template())

    with open(os.path.join(output_dir, "README.md"), "w", encoding="utf-8") as f:
        f.write(get_readme_template())

    src_dir = os.path.join(output_dir, "src")
    os.makedirs(src_dir, exist_ok=True)

    # 3. Provision the Python namespace
    init_path = os.path.join(src_dir, "__init__.py")
    if not os.path.exists(init_path):
        with open(init_path, "w", encoding="utf-8") as f:
            f.write('"""Federated Generative Model internal dependencies and mathematical logic."""\n')

    # 4. Provide a dedicated utils.py to guide the researcher
    utils_path = os.path.join(src_dir, "utils.py")
    if not os.path.exists(utils_path):
        with open(utils_path, "w", encoding="utf-8") as f:
            f.write('"""Place your PyTorch/Keras helper functions, custom data loaders, and DP utilities here."""\n')

    print("✅ Secure 'src/' layout enforced for dependency isolation.")
    print("✅ Project structure initialized successfully.")


def run_simulate(args: argparse.Namespace) -> None:
    """Handler for the 'simulate' command."""
    from .simulation import run_local_simulation
    from model_store_interface.metadata.models.dataset_meta import DatasetMeta

    print(f"🔬 Executing local federated simulation in '{args.mode}' mode...")

    # Load local data and metadata based on CLI arguments
    data = pd.read_csv(args.data_path)
    with open(args.meta_path, "r", encoding="utf-8") as f:
        dataset_meta = DatasetMeta.model_validate_json(f.read())

    # Dynamically import the researcher's model from the local workspace
    import example
    federated_model = example.federated_model

    run_local_simulation(
        model=federated_model,
        data=data,
        dataset_meta=dataset_meta,
        n_nodes=args.n_nodes,
        n_rounds=args.n_rounds,
        output_dir=args.output_dir,
        n_samples=args.n_samples,
        mode=args.mode
    )


def run_upload(args: argparse.Namespace) -> None:
    """Interactive wizard to upload a model to MLflow."""
    import importlib
    from .mlflow_interface import submit_fl_model

    print("\n🚀 MSI Model Upload Wizard")
    print("-" * 30)

    # Interactive fallbacks
    model_locator = args.model or input("Model locator (e.g., example:federated_model): ") or "example:federated_model"
    code_paths_str = args.code_paths or input("Code paths to bundle (comma-separated, default 'src'): ") or "src"

    paths = [p.strip() for p in code_paths_str.split(",")] if code_paths_str else None

    print(f"\n📦 Loading model from {model_locator}...")
    try:
        module_name, attr_name = model_locator.split(":")
        module = importlib.import_module(module_name)
        federated_model = getattr(module, attr_name)
    except Exception as e:
        print(f"❌ Failed to load model: {e}")
        sys.exit(1)

    try:
        print("☁️ Submitting model to the Federated Platform...")
        upload_result = submit_fl_model(
            model=federated_model,
            platform_url=args.platform_url,
            username=args.username,
            password=args.password,
            experiment_name=args.experiment,
            use_case=args.use_case,
            trained=args.trained,
            metadata_path=args.meta_path,
            license_path=args.license_path,
            code_paths=paths
        )
        print("\n✅ Model uploaded successfully!")
        print(f"   Model URI: {upload_result['model_uri']}")
        print(f"   Run ID:    {upload_result['run_id']}")
    except Exception as e:
        print(f"\n❌ Upload failed: {e}")
        sys.exit(1)


# ---------------------------------------------------------------------------
# CLI ENTRY POINT
# ---------------------------------------------------------------------------
def main() -> None:
    """Entry point for the msi CLI tool."""
    # Ensure CLI can dynamically import local files like 'example.py' [3]
    sys.path.insert(0, os.getcwd())

    parser = argparse.ArgumentParser(description="Model Store Interface (MSI) CLI Toolkit")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # 1. INIT COMMAND
    init_parser = subparsers.add_parser("init", help="Scaffold a new MSI project")
    init_parser.add_argument("output_dir", nargs="?", default=".",
                             help="Target directory for scaffolding.")
    init_parser.add_argument("--template", choices=["noop", "pytorch", "keras", "scikit-learn"],
                             default="noop")
    init_parser.add_argument("--dp", action="store_true",
                             help="Include Differential Privacy (DP) wrappers.")
    init_parser.set_defaults(func=run_init)

    # 2. SIMULATE COMMAND
    simulate_parser = subparsers.add_parser("simulate", help="Execute a local federated simulation")
    simulate_parser.add_argument("--mode", choices=["loop", "flower"], default="loop",
                                 help="Simulation engine (default: loop)")
    simulate_parser.add_argument("--data-path", default="data.csv",
                                 help="Path to the training data CSV file")
    simulate_parser.add_argument("--meta-path", default="dataset_meta.json",
                                 help="Path to the DatasetMeta JSON file")
    simulate_parser.add_argument("--output-dir", default="./simulation_output",
                                 help="Directory where reports are saved")
    simulate_parser.add_argument("--n-nodes", type=int, default=2, help="Number of virtual FL nodes")
    simulate_parser.add_argument("--n-rounds", type=int, default=3, help="Number of FL training rounds")
    simulate_parser.add_argument("--n-samples", type=int, default=1000,
                                 help="Number of synthetic samples to generate")
    simulate_parser.set_defaults(func=run_simulate)

    # 3. UPLOAD COMMAND
    upload_parser = subparsers.add_parser("upload", help="Interactive wizard to upload a model to MLflow")
    upload_parser.add_argument("--model",
                               help="Model definition entrypoint (e.g. example:federated_model)")
    upload_parser.add_argument("--platform-url", help="MLflow Tracking URI")
    upload_parser.add_argument("--username", help="Platform Username")
    upload_parser.add_argument("--password", help="Platform Password")
    upload_parser.add_argument("--experiment", help="Experiment name")
    upload_parser.add_argument("--use-case", help="Target Use Case (e.g. AML)")
    upload_parser.add_argument("--code-paths", default="src", help="Path to local dependencies")
    upload_parser.add_argument("--requirements", help="Path to requirements.txt")
    upload_parser.add_argument(
        "--trained",
        action="store_true",
        default=False,
        help="Flag indicating if the federated model has already completed training."
    )
    upload_parser.add_argument(
        "--meta-path",
        type=str,
        default="dataset_meta.json",
        help="Path to the DCAT-AP dataset metadata"
    )
    upload_parser.add_argument(
        "--license-path",
        type=str,
        default="LICENSE",
        help="Path to the model license"
    )
    upload_parser.set_defaults(func=run_upload)

    # ---------------------------------------------------------
    # DISPATCH EXECUTION
    # ---------------------------------------------------------
    args = parser.parse_args()

    if hasattr(args, "func"):
        args.func(args)
    else:
        parser.print_help()

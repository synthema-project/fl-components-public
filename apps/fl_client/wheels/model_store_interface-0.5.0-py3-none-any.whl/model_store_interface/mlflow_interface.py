import io
import logging
import os
import shutil
import tempfile
import tomllib  # Native in Python 3.11+
import warnings
from typing import Optional, List

import boto3
import mlflow
import pandas as pd
from botocore.exceptions import ClientError
from mlflow.pyfunc import log_model
from mlflow.pyfunc.model import PythonModel
from mlflow.tracking import MlflowClient

from .aggregator_protocol import AggFactoryProtocol, AggProtocol
from model_store_interface.metadata.models.dataset_meta import DatasetMeta, UseCase
from .core.utils import load_meta_from_path
from .default_create_functions import _create_noop_local_learner, default_create_aggregator
from .local_learner_protocol import LLFactoryProtocol, LLProtocol

logger = logging.getLogger(__name__)


class FederatedModel(PythonModel):
    """
    A class for creating a federated learning model and its aggregator. If no aggregator is provided
    the PlainAVGAggregator is passed as default

    This class encapsulates the local learner, the aggregation strategy, and their respective names.
    It is designed to facilitate the integration of these components into the MLflow tracking system.

    Attributes:
        create_aggregator (AggFactoryProtocol): The function pointer to generate an aggregator
        aggregator_name (str): The name of the aggregation strategy (default is "PlainAVG").
        create_local_learner (LLFactoryProtocol): The function pointer to generate a local model
        model_name (str): The name of the model to be registered in MLflow.
    """

    def __init__(self, create_local_learner: LLFactoryProtocol = _create_noop_local_learner,
                 model_name: str = "Default_iris_model",
                 create_aggregator: AggFactoryProtocol = default_create_aggregator,
                 aggregator_name: str = "PlainAVG"
                 ) -> None:
        self.create_aggregator = create_aggregator
        self.aggregator_name = aggregator_name
        self.create_local_learner = create_local_learner
        self.model_name = model_name


def submit_fl_model(
        model: 'FederatedModel',
        platform_url: str,
        username: str,
        password: str,
        experiment_name: str,
        use_case: str,
        trained: bool,
        metadata_path: str,
        license_path: str,
        code_paths: Optional[List[str]] = None,
) -> dict:
    """
    Submit the model, schema, aggregation strategy and weights (if trained) to MLflow.
    Strictly prohibits the upload of local simulation outputs or reports.

    Automatically infers dependencies from pyproject.toml.

    This function logs the model and aggregator as artifacts, registers the model in MLflow,
    and ensures a new run is created in the specified experiment.

    Args:
        model (FederatedModel): The federated learning model to be submitted.
        platform_url (str): The URL of the MLflow tracking server.
        username (str): The username for authenticating with the MLflow tracking server.
        password (str): The password for authenticating with the MLflow tracking server.
        experiment_name (str): The name of the MLflow experiment to use or create.
        use_case (str): The use case for the model.
        trained (bool): Indicates whether the model is already trained.
        code_paths (Optional[List[str]]): source file path list for the model to upload
        metadata_path (Optional[str]): The metadata json file with the structure
        license_path (Optional[str]): The LICENSE file path linked to the model
    Raises:
        RuntimeError: If the username or password is not provided.
    """
    # 1. DevSecOps Authentication & Domain Gate
    if not username or not password:
        raise RuntimeError("CRITICAL: Username and password must be provided.")

    valid_use_cases = [uc.value for uc in UseCase]
    if use_case not in valid_use_cases:
        raise ValueError(f"CRITICAL: Use case must be either {', '.join(valid_use_cases)}.")

    # 2. Strict MLOps Protocol Enforcement with Exception Chaining
    try:
        test_learner = model.create_local_learner()
        if not isinstance(test_learner, LLProtocol):
            raise TypeError(
                "CRITICAL: The local learner factory returned an object that violates the strict LLProtocol "
                "signatures.")

        test_aggregator = model.create_aggregator()
        if not isinstance(test_aggregator, AggProtocol):
            raise TypeError(
                "CRITICAL: The aggregator factory returned an object that violates the strict AggProtocol signatures.")

    except Exception as e:
        # Explicit exception chaining preserves the __traceback__ for edge debugging
        raise RuntimeError(
            "CRITICAL: Failed to instantiate and mathematically validate federated components prior to upload."
        ) from e

    # 3. Data Contracts Gate
    if not os.path.exists(metadata_path):
        raise FileNotFoundError(f"CRITICAL: DCAT-AP schema not found at '{metadata_path}'.")
    if not os.path.exists(license_path):
        raise FileNotFoundError(f"CRITICAL: LICENSE file not found at '{license_path}'.")

    # 2. Dependency Inference & Intelligent Code Scoping
    pip_requirements = []
    if os.path.exists("pyproject.toml"):
        with open("pyproject.toml", "rb") as f:
            pyproject_data = tomllib.load(f)
            pip_requirements = pyproject_data.get("project", {}).get("dependencies", [])

    if not code_paths:
        code_paths = []

    # A) Bind the entire 'src' directory recursively (MLflow handles the tree natively)
    if os.path.exists("src") and os.path.isdir("src") and "src" not in code_paths:
        code_paths.append("src")

    # B) Dynamically bind all root-level .py files (e.g., example.py)
    # This prevents catastrophic traversal into .venv/ or simulation_output/
    root_py_files = [f for f in os.listdir(".") if f.endswith(".py") and os.path.isfile(f)]
    for py_file in root_py_files:
        if py_file not in code_paths:
            code_paths.append(py_file)

    # Only bundle files/dirs that physically exist in the researcher's workspace
    valid_code_paths = [p for p in code_paths if os.path.exists(p)]

    # 3. Robust Dependency Resolution (Capturing Deep Learning Extras)
    pip_requirements = None
    if os.path.exists("requirements.txt"):
        # Absolute lockfile guarantee takes precedence
        pip_requirements = "requirements.txt"
    elif os.path.exists("pyproject.toml"):
        # Fallback to dynamic parsing including all ML extras
        with open("pyproject.toml", "rb") as f:
            pyproject_data = tomllib.load(f)
            deps = pyproject_data.get("project", {}).get("dependencies", [])
            extras = pyproject_data.get("project", {}).get("optional-dependencies", {})
            for extra_deps in extras.values():
                deps.extend(extra_deps)
            pip_requirements = list(set(deps))  # Deduplicate

    # 4. Rename LICENSE for MLflow UI Rendering
    license_txt_path = license_path
    if not license_path.endswith(".txt"):
        license_txt_path = license_path + ".txt"
        shutil.copy(license_path, license_txt_path)

    # 5. MLOps Backend Connection
    os.environ["MLFLOW_TRACKING_USERNAME"] = username
    os.environ["MLFLOW_TRACKING_PASSWORD"] = password
    mlflow.set_tracking_uri(platform_url)

    client = MlflowClient()
    existing_exp = client.get_experiment_by_name(experiment_name)

    if existing_exp is not None and getattr(existing_exp, "lifecycle_stage", "active") == "deleted":
        logger.warning(f"Experiment '{experiment_name}' is soft-deleted. Executing automatic restoration.")
        client.restore_experiment(existing_exp.experiment_id)

    # 1. Load the SSOT
    dataset_meta_ssot = load_meta_from_path(metadata_path)

    # 2. Mathematically sanitise the payload for the public registry
    publish_view = dataset_meta_ssot.project_for_publish()

    mlflow.set_experiment(experiment_name=experiment_name)

    # 6. Execute the MLflow Run
    with mlflow.start_run() as run:
        mlflow.set_tag("use_case", use_case)
        mlflow.set_tag("trained", str(trained))

        with tempfile.NamedTemporaryFile(mode="w", delete=False, suffix=".json") as tmp_meta:
            tmp_meta.write(publish_view.model_dump_json(indent=2))
            tmp_meta_path = tmp_meta.name

            # Log Run Artifacts for UI Visibility
            mlflow.log_artifact(tmp_meta_path)
            mlflow.log_artifact(license_txt_path)
            for extra_file in ["pyproject.toml", "uv.lock", "README.md"]:
                if os.path.exists(extra_file):
                    mlflow.log_artifact(extra_file)

            # Bundle PyFunc Context Artifacts
            artifacts = {
                "dataset_meta": tmp_meta_path,
                "license": license_txt_path
            }

            model_info = log_model(
                artifact_path="model",
                python_model=model,
                registered_model_name=model.model_name,
                pip_requirements=pip_requirements,
                code_paths=valid_code_paths if valid_code_paths else None,
                artifacts=artifacts
            )

            # Cleanup temporary text license
            if license_txt_path != license_path and os.path.exists(license_txt_path):
                os.remove(license_txt_path)

        os.remove(tmp_meta_path)

        return {
            "detail": "Model successfully registered to the Federated Platform.",
            "model_uuid": model_info.model_uuid,
            "run_id": run.info.run_id,
            "model_uri": model_info.model_uri,
            "experiment_id": run.info.experiment_id,
            "experiment_name": experiment_name
        }


# FIXME: This function must not be included here. It must be present only in fl-components in the server side
def submit_synthetic_data_pool(
        data: pd.DataFrame,
        dataset_meta: DatasetMeta,
        s3_endpoint_url: str,
        access_key: str,
        secret_key: str,
        use_case: str,
        sdg_model_name: str,
        create_s3_bucket_if_missing=False
) -> dict:
    """
    Submits synthetically generated data and its metadata to an S3-compatible service (like MinIO).
    
    The data is uploaded as a CSV file and the metadata is uploaded as a JSON file to a
    fixed bucket named 'synthetic-data-for-inference', under a folder structure of {disease}/{dataset_name}/.

    Args:
        data (DataFrame): The synthetic data samples stored as a pandas DataFrame.
        dataset_meta (DatasetMeta): The metadata describing the data model.
        s3_endpoint_url (str): The S3/MinIO endpoint URL (e.g. 'https://minio.example.com').
        access_key (str): The Access Key ID for authentication.
        secret_key (str): The Secret Access Key for authentication.
        use_case (str): The use-case category.
        sdg_model_name (str): The specific name of this SDG model, used as a subfolder in S3.
        create_s3_bucket_if_missing (bool): Create the Minio general SDG model bucket if not available

    Returns:
        dict: A dictionary containing details of the upload, including the S3 paths of the uploaded files.
    """
    warnings.warn(
        "`submit_synthetic_data_pool` is deprecated. Upload logic is now owned by `fl-components`.",
        DeprecationWarning,
        stacklevel=2
    )

    if use_case not in [e.value for e in UseCase]:
        valid_cases = ", ".join([repr(e.value) for e in UseCase])
        raise ValueError(f"Use case must be either {valid_cases}")

    # Initialize the S3 client
    s3_client = boto3.client(
        's3',
        endpoint_url=s3_endpoint_url,
        aws_access_key_id=access_key,
        aws_secret_access_key=secret_key,
    )

    bucket_name = "synthetic-data-for-inference"

    # Ensure the bucket exists
    try:
        s3_client.head_bucket(Bucket=bucket_name)
    except ClientError as e:
        error_code = (e.response['Error']['Code']).lower()
        if error_code in ['404', 'nosuchbucket', 'notfound']:
            # Bucket does not exist, let's create it
            if create_s3_bucket_if_missing:
                s3_client.create_bucket(Bucket=bucket_name)
                logger.warning(f"Creating new s3 bucket {bucket_name}. It should already be available")
            else:
                raise PermissionError(f"The s3 bucket {bucket_name} does not exist and submit_synthetic_data_pool "
                                      f"called without create_s3_bucket_if_missing") from e
        elif error_code in ['403', '401']:
            raise PermissionError(f"Access denied. Cannot verify or create bucket '{bucket_name}'. "
                                  f"Please check your credentials and S3 policies: {e}")
        else:
            raise e

    # Generate paths
    base_prefix = f"{use_case}/{sdg_model_name}"
    data_path = f"{base_prefix}/data.csv"
    meta_path = f"{base_prefix}/dataset_meta.json"

    # Serialize DataFrame to CSV bytes
    csv_buffer = io.BytesIO()
    data.to_csv(csv_buffer, index=False)
    csv_buffer.seek(0)

    # Convert DatasetMeta to JSON bytes
    # model_dump_json serializes the Pydantic model to a JSON string
    meta_json_str = dataset_meta.model_dump_json(exclude_none=True)
    meta_buffer = io.BytesIO(meta_json_str.encode("utf-8"))

    # Upload data
    s3_client.put_object(
        Bucket=bucket_name,
        Key=data_path,
        Body=csv_buffer.getvalue(),
        ContentType='text/csv'
    )

    # Upload metadata
    s3_client.put_object(
        Bucket=bucket_name,
        Key=meta_path,
        Body=meta_buffer.getvalue(),
        ContentType='application/json'
    )

    return {
        "detail": f"Synthetic dataset '{sdg_model_name}' for '{use_case}' successfully submitted.",
        "bucket": bucket_name,
        "data_path": data_path,
        "meta_path": meta_path,
        "s3_data_uri": f"s3://{bucket_name}/{data_path}",
        "s3_metadata_uri": f"s3://{bucket_name}/{meta_path}"
    }

from typing import Protocol, runtime_checkable

import flwr
from pandas import DataFrame

from .core.dataset_partition import DatasetPartition
from model_store_interface.metadata.dataset_views import ComputeDatasetView


@runtime_checkable
class LLProtocol(Protocol):
    """
    Protocol for defining a local learner in a federated learning setup.
    """

    def prepare_data(self, data: DataFrame, partition: DatasetPartition,
                     dataset_meta: ComputeDatasetView) -> DataFrame:
        """
        Prepares and loads dataset partitions with optional metadata.

        Parameters:
          - data: Pandas Dataframe to prepare
          - partition: partition type to process
          - dataset_meta: DatasetMeta Pydantic model or path to JSON file.

        Behavior:
          - If `dataset_meta` is a path (str), implementations should use utils.load_meta_from_path.
          - Implementations should set an accessible attribute `self.dataset_schema` (DatasetMeta) with loaded metadata.
        """
        ...

    def train_round(self, data: DataFrame, dataset_meta: ComputeDatasetView) -> flwr.common.MetricsRecord:
        """
        Trains the model and returns metrics.
        Args:
            data: preprocessed dataset (prepare_data already run)
            dataset_meta: pydantic representation of the dataset structure (global)
        Returns:
            flwr.common.MetricsRecord: Performance metrics after training.
        """
        ...

    def get_parameters(self) -> flwr.common.ParametersRecord:
        """
        Retrieves the current model parameters.
        Returns:
            flwr.common.ParametersRecord: Current model parameters.
        """
        ...

    def set_parameters(self, parameters: flwr.common.ParametersRecord) -> None:
        """
        Sets the model parameters.
        Args:
            parameters: A flwr.common.ParametersRecord containing the parameters to set.
        """
        ...

    def evaluate(self, data: DataFrame, dataset_meta: ComputeDatasetView) -> flwr.common.MetricsRecord:
        """
        Evaluates the model and returns performance metrics.
        Args:
            data: preprocessed dataset (prepare_data already run)
            dataset_meta: pydantic representation of the dataset structure (global)
        Returns:
            flwr.common.MetricsRecord: Evaluation metrics.
        """
        ...

    def generate_synthetic_data(self, n_samples: int, dataset_meta: ComputeDatasetView) -> DataFrame:
        """
        Generates synthetic data samples using the trained model.
        
        This method is called after the final training round on a selected node.
        
        Args:
            n_samples: Number of synthetic samples to generate
            dataset_meta: Dataset metadata for schema consistency and transformations
                         (e.g., inverting categorical mappings)
        
        Returns:
            DataFrame: Synthetic samples with the same schema as the original data
        """
        ...


@runtime_checkable
class LLFactoryProtocol(Protocol):
    """
    Protocol for the function creating the local learner instance
    """

    def __call__(self) -> LLProtocol:
        """
        Creates and returns an instance of a class conforming to LLProtocol.
        """
        ...

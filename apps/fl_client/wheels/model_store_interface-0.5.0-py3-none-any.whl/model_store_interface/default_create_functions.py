# Create your custom function defining a PyTorch-based model and returning its instance


def _create_noop_local_learner():
    import pandas as pd
    import numpy as np
    import flwr
    from model_store_interface.core.dataset_partition import DatasetPartition
    from model_store_interface.metadata.models.dataset_meta import DatasetMeta

    class NoOpLocalLearner:
        def prepare_data(self, data: pd.DataFrame, partition: DatasetPartition,
                         dataset_meta: DatasetMeta) -> pd.DataFrame:
            return data

        def train_round(self, data: pd.DataFrame, dataset_meta: DatasetMeta) -> flwr.common.MetricsRecord:
            return flwr.common.MetricsRecord({"loss": 0.0})

        def get_parameters(self) -> flwr.common.ParametersRecord:
            return flwr.common.ParametersRecord({})

        def set_parameters(self, parameters: flwr.common.ParametersRecord) -> None:
            pass

        def evaluate(self, data: pd.DataFrame, dataset_meta: DatasetMeta) -> flwr.common.MetricsRecord:
            return flwr.common.MetricsRecord({"accuracy": 1.0})

        def generate_synthetic_data(self, n_samples: int, dataset_meta: DatasetMeta) -> pd.DataFrame:
            data = {}
            for var in dataset_meta.variables:
                if var.type == "numeric":
                    data[var.name] = np.random.randn(n_samples)
                elif var.type == "categorical":
                    options = np.array(var.categories if var.categories else ["A", "B"])
                    data[var.name] = np.random.choice(options, n_samples)
                else:
                    data[var.name] = np.random.randn(n_samples)
            return pd.DataFrame(data)

    return NoOpLocalLearner()


def default_create_local_learner():
    return _create_noop_local_learner()


# Create your custom function defining an aggregation strategy and returning its instance
def default_create_aggregator():
    from collections import OrderedDict
    import numpy as np
    import flwr
    from typing import Optional
    from model_store_interface.dp.dp_wrappers import FedAvgAccountant
    from .core.utils import Utils  # Dependency script stored inside the core directory

    class DefaultAggregator:

        def aggregate_parameters(self, results: list[flwr.common.ParametersRecord],
                                 config: Optional[flwr.common.ConfigsRecord] = None
                                 ) -> flwr.common.ParametersRecord:
            # Guard against empty participation sets to prevent IndexError
            if not results:
                return flwr.common.ParametersRecord({})

            parameters = [Utils.parameters_to_dict(param) for param in results]
            keys = parameters[0].keys()
            result = OrderedDict()
            for key in keys:
                # Init array
                this_array: np.ndarray = np.zeros_like(parameters[0][key])
                for p in parameters:
                    this_array += p[key]
                result[key] = this_array / len(results)
            return Utils.dict_to_parameter_record(result)

        def aggregate_metrics(self, results: list[flwr.common.MetricsRecord],
                              config: Optional[flwr.common.ConfigsRecord] = None) -> flwr.common.MetricsRecord:
            # Guard against empty metric reporting packages to prevent IndexError
            if not results:
                return flwr.common.MetricsRecord({})

            keys = results[0].keys()
            result = OrderedDict()
            for key in keys:
                if key == "privacy_budget":
                    cumulative_epsilon = []
                    cumulative_delta = []
                    for m in results:
                        cumulative_epsilon.append(m[key][0])
                        cumulative_delta.append(m[key][1])
                    accountant = FedAvgAccountant()
                    accountant.update(cumulative_epsilon, cumulative_delta)
                    global_privacy_budget = accountant.get_privacy_spent()
                    for key, val in global_privacy_budget.items():
                        result[key] = val
                else:
                    # Init array
                    cumsum = 0.0
                    for m in results:
                        if not isinstance(m[key], (int, float)):
                            raise ValueError(
                                f"flwr.common.MetricsRecord value type not supported: {type(m[key])}"
                            )
                        cumsum += m[key]  # type: ignore
                    result[key] = cumsum / len(results)
            return flwr.common.MetricsRecord(result)  # type: ignore

    return DefaultAggregator()

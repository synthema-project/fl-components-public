import re
from enum import Enum
from typing import List, Optional, Dict, Literal, Any

from pydantic import BaseModel, Field, field_validator, model_validator, ConfigDict


class UseCase(str, Enum):
    """Strict enumeration of supported clinical domains for MLOps tracking and validation."""

    AML = "AML"
    SCD = "SCD"
    AML_PUBLIC = "AML (public)"


class Variable(BaseModel):
    """
    Canonical variable definition (internal truth)
    """
    model_config = ConfigDict(extra="allow")

    name: str = Field(..., description="Variable name")
    type: Literal["numeric", "integer", "categorical", "binary", "datetime", "text"] = Field(
        ..., description="Variable type"
    )

    unit: Optional[str] = Field(None, description="Unit of measurement")

    # Statistics for numeric
    min: Optional[float] = Field(None, description="Minimum value")
    max: Optional[float] = Field(None, description="Maximum value")
    mean: Optional[float] = Field(None, description="Mean value")
    median: Optional[float] = Field(None, description="Median value")
    std: Optional[float] = Field(None, description="Standard deviation")

    # preprocessing
    categories: Optional[List[str]] = Field(None, description="List of category values")
    mapping: Optional[Dict[str, int]] = Field(
        None, description="Mapping from category string to integer"
    )
    imputation: Optional[Literal["median", "mean", "mode", "none"]] = Field(
        None, description="Imputation strategy for missing values"
    )

    # Data quality
    missing_rate: Optional[float] = Field(
        None, ge=0.0, le=1.0, description="Proportion of missing values"
    )

    # Domain-specific
    omop_concept_id: Optional[str] = Field(None, description="OMOP concept identifier")
    radeep_term: Optional[str] = Field(None, description="Radeep terminology term")
    sensitivity: Optional[Literal["low", "medium", "high"]] = Field(
        None, description="Data sensitivity level"
    )

    @field_validator("mapping", mode="after")
    @classmethod
    def validate_mapping_values(cls, mapping: Optional[Dict[str, int]], info):
        """Ensure mapping values are unique integers."""
        if mapping:
            values = list(mapping.values())
            if not all(isinstance(v, int) for v in values):
                raise ValueError("All mapping values must be integers")
            if len(values) != len(set(values)):
                raise ValueError("Mapping values must be unique")
        return mapping

    @model_validator(mode="after")
    def validate_categories_mapping_consistency(self):
        """Ensure consistency between categories and mapping for categorical/binary variables."""
        if self.type in ["categorical", "binary"]:
            if not self.categories or not self.mapping:
                raise ValueError(
                    f"Variables of type '{self.type}' must have both 'categories' and 'mapping' defined"
                )
            if self.mapping:
                mapping_keys = set(self.mapping.keys())
                cat_set = set(str(c) for c in self.categories)
                if mapping_keys != cat_set:
                    missing_in_mapping = cat_set - mapping_keys
                    extra_in_mapping = mapping_keys - cat_set
                    msg = "Mapping keys must match categories exactly."
                    if missing_in_mapping:
                        msg += f" Missing in mapping: {missing_in_mapping}"
                    if extra_in_mapping:
                        msg += f" Extra in mapping: {extra_in_mapping}"
                    raise ValueError(msg)
        return self


class DatasetMeta(BaseModel):
    """
    SINGLE SOURCE OF TRUTH
    """

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    title: str = Field(..., description="Dataset title")
    version: str = Field(..., description="Dataset version")
    schema_version: str = Field(
        "dataset_meta_v1", description="Schema version for dataset_meta"
    )
    use_case: UseCase = Field(
        default=None,
        description="The specific clinical domain or use case (e.g., 'aml', 'scd') "
                    "to explicitly target validation plugins."
    )

    description: Optional[str] = Field(None, description="Dataset description")
    id: Optional[str] = Field(None, description="Dataset URI identifier")
    issued: Optional[str] = Field(None, description="ISO date when dataset was issued")

    context: Optional[str] = Field(None, alias="@context", description="Optional JSON-LD context URI or object")
    publisher: Optional[Dict[str, Any]] = Field(None, description="Publisher information")
    distributions: Optional[List[Dict[str, Any]]] = Field(
        None, description="Distribution descriptors (format, size, URL)"
    )

    omop_profile: Optional[str] = Field(
        None, description="OMOP CDM profile version if applicable"
    )

    meta_hash: Optional[str] = Field(
        None, pattern=r"^[a-fA-F0-9]{64}$", description="SHA256 hex of canonicalized meta (computed field)"
    )
    notes: Optional[str] = Field(None, description="Additional notes")

    variables: List[Variable]

    @field_validator("meta_hash", mode="after")
    @classmethod
    def validate_meta_hash_format(cls, meta_hash: Optional[str]):
        """Validate meta_hash format if provided."""
        if meta_hash and not re.match(r"^[a-fA-F0-9]{64}$", meta_hash):
            raise ValueError("meta_hash must be a valid SHA256 hex string (64 characters)")
        return meta_hash

    @field_validator("variables", mode="after")
    @classmethod
    def validate_unique_variable_names(cls, variables: List[Variable]):
        """Ensure no duplicate variable names."""
        names = [v.name for v in variables]
        if len(names) != len(set(names)):
            duplicates = [n for n in names if names.count(n) > 1]
            raise ValueError(f"Duplicate variable names: {set(duplicates)}")
        return variables

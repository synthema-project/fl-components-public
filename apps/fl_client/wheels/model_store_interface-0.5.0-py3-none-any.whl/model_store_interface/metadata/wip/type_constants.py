"""
Centralized type mappings for metadata transformations.

This module defines a single source of truth for converting between:
- internal variable types (used in DatasetMeta)
- external representations (e.g., HealthDCAT)

Keep this minimal and explicit.
"""

# ---------------------------
# Internal → HealthDCAT
# ---------------------------

_INTERNAL_TO_HEALTH = {
    "numeric": "Decimal",
    "integer": "Integer",
    "categorical": "Categorical",
    "binary": "Binary",
    "datetime": "DateTime",
    "text": "Text",
}

# ---------------------------
# HealthDCAT → Internal
# ---------------------------

_HEALTH_TO_INTERNAL = {v: k for k, v in _INTERNAL_TO_HEALTH.items()}


# ---------------------------
# Public API
# ---------------------------

def to_health_type(internal_type: str) -> str:
    """
    Convert internal variable type → HealthDCAT datatype.

    Example:
        "numeric" → "Decimal"
    """
    if internal_type not in _INTERNAL_TO_HEALTH:
        raise ValueError(
            f"Unsupported internal type '{internal_type}'. "
            f"Supported: {list(_INTERNAL_TO_HEALTH.keys())}"
        )
    return _INTERNAL_TO_HEALTH[internal_type]


def to_internal_type(health_type: str) -> str:
    """
    Convert HealthDCAT datatype → internal variable type.

    Example:
        "Decimal" → "numeric"
    """
    if health_type not in _HEALTH_TO_INTERNAL:
        raise ValueError(
            f"Unsupported HealthDCAT type '{health_type}'. "
            f"Supported: {list(_HEALTH_TO_INTERNAL.keys())}"
        )
    return _HEALTH_TO_INTERNAL[health_type]

from typing import List, Optional, Dict

from pydantic import BaseModel

from model_store_interface.metadata.wip.model import DatasetMeta
from model_store_interface.metadata.wip.type_constants import to_health_type


class ComputeVariable(BaseModel):
    name: str
    type: str
    mapping: Optional[Dict[str, int]]
    imputation: Optional[str]


class ComputeView(BaseModel):
    variables: List[ComputeVariable]

    @classmethod
    def from_dataset_meta(cls, meta: DatasetMeta) -> "ComputeView":
        return ComputeView(
            variables=[
                ComputeVariable(
                    name=v.name,
                    type=v.type,
                    mapping=v.mapping,
                    imputation=v.imputation
                )
                for v in meta.variables
                if v.type in ("numeric", "integer", "categorical", "binary")
            ]
        )


class EvaluationVariable(BaseModel):
    name: str
    type: str
    sensitivity: Optional[str]
    missing_rate: Optional[float]


class EvaluationView(BaseModel):
    variables: List[EvaluationVariable]

    @classmethod
    def from_dataset_meta(cls, meta: DatasetMeta) -> "EvaluationView":
        return EvaluationView(
            variables=[
                EvaluationVariable(
                    name=v.name,
                    type=v.type,
                    sensitivity=v.sensitivity,
                    missing_rate=v.missing_rate,
                )
                for v in meta.variables
            ]
        )


class HealthDCATVariable(BaseModel):
    name: str
    datatype: str
    description: str

    min: Optional[float]
    max: Optional[float]
    mean: Optional[float]
    median: Optional[float]
    std: Optional[float]

    categories: Optional[List[str]]
    mapping: Optional[Dict[str, str]]

    imputation: Optional[str]
    missing_rate: Optional[float]

    sensitivity: Optional[str]


class HealthDCATView(BaseModel):
    title: str
    version: str
    description: Optional[str]
    variables: List[HealthDCATVariable]

    @classmethod
    def from_dataset_meta(cls, meta: DatasetMeta) -> "HealthDCATView":
        return HealthDCATView(
            title=meta.title,
            version=meta.version,
            description=meta.description,
            variables=[
                HealthDCATVariable(
                    name=v.name,
                    datatype=to_health_type(v.type),

                    description=v.name,

                    min=v.min,
                    max=v.max,
                    mean=v.mean,
                    median=v.median,
                    std=v.std,

                    categories=v.categories,

                    mapping=(
                        {k: str(val) for k, val in v.mapping.items()}
                        if v.mapping else None
                    ),

                    imputation=v.imputation,
                    missing_rate=v.missing_rate,

                    sensitivity=v.sensitivity,
                )
                for v in meta.variables
            ]
        )

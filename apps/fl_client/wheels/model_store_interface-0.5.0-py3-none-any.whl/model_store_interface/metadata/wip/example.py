from model_store_interface.metadata.wip.model import DatasetMeta
from model_store_interface.metadata.wip.views import EvaluationView, ComputeView, HealthDCATView


input_json = {"title": "Myname",
              "version": "1.0",
              "schema_version": "1.0",
              "use_case": "AML",
              "variables": [{"name": "fake_var", "type": "numeric"}]
                  }
meta = DatasetMeta.model_validate(input_json)

compute = ComputeView.from_dataset_meta(meta)
eval_view = EvaluationView.from_dataset_meta(meta)
healthdcat_view = HealthDCATView.from_dataset_meta(meta)

print(f"Compute view. {type(compute)}: {compute.model_dump()}")
print(f"Eval view: {type(eval_view)}: {eval_view.model_dump()}")
print(f"HealthDCAT view: {type(healthdcat_view)}: {healthdcat_view.model_dump()}")

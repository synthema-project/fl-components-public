from typing import Dict, Any

from model_store_interface.metadata.wip.model import DatasetMeta, Variable
from model_store_interface.metadata.wip.type_constants import (to_internal_type,
                                                               to_health_type)


# ---------------------------
# JSON → internal model
# ---------------------------

def from_json(data: Dict[str, Any]) -> DatasetMeta:
    """
    Convert input JSON (HealthDCAT-style) into internal DatasetMeta.

    Expected input format:
    {
        "dataset_meta": {
            "title": "...",
            "version": "...",
            "variables": [...]
        }
    }
    """

    d = data["dataset_meta"]

    return DatasetMeta(
        title=d["title"],
        version=d["version"],
        description=d.get("description"),

        variables=[
            Variable(
                name=v["name"],
                type=to_internal_type(v["datatype"]),

                # stats
                min=v.get("min"),
                max=v.get("max"),
                mean=v.get("mean"),
                median=v.get("median"),
                std=v.get("std"),
                missing_rate=v.get("missing_rate"),

                # preprocessing
                categories=v.get("categories"),
                mapping={
                    k: int(val)
                    for k, val in (v.get("mapping") or {}).items()
                } if v.get("mapping") else None,
                imputation=v.get("imputation"),

                # privacy
                sensitivity=v.get("sensitivity"),

                # domain
                omop_concept_id=v.get("omop_concept_id"),
                radeep_term=v.get("radeep_term"),
            )
            for v in d["variables"]
        ]
    )


# ---------------------------
# internal model → JSON
# ---------------------------

def to_json(meta: DatasetMeta) -> Dict[str, Any]:
    """
    Convert DatasetMeta into HealthDCAT-style JSON.
    """

    return {
        "dataset_meta": {
            "title": meta.title,
            "version": meta.version,
            "description": meta.description,
            "variables": [
                {
                    "name": v.name,
                    "datatype": to_health_type(v.type),

                    "description": v.name,

                    # stats
                    "min": v.min,
                    "max": v.max,
                    "mean": v.mean,
                    "median": v.median,
                    "std": v.std,
                    "missing_rate": v.missing_rate,

                    # preprocessing
                    "categories": v.categories,
                    "mapping": (
                        {k: str(val) for k, val in v.mapping.items()}
                        if v.mapping else None
                    ),
                    "imputation": v.imputation,

                    # privacy
                    "sensitivity": v.sensitivity,

                    # domain
                    "omop_concept_id": v.omop_concept_id,
                    "radeep_term": v.radeep_term,
                }
                for v in meta.variables
            ]
        }
    }

from __future__ import annotations

import hashlib
import json
import re
from typing import TYPE_CHECKING, Optional, Dict, List, Any

from pydantic import BaseModel, Field, field_validator, ConfigDict

if TYPE_CHECKING:
    from model_store_interface.metadata.health_dcat_ap_dataset_meta import (
        Distribution as HealthDcatDistribution,
        Publisher as HealthDcatPublisher,
        Variable as HealthDcatVariable,
    )

from model_store_interface.metadata.models.common import Variable, UseCase
from model_store_interface.metadata.dataset_views import (
    ComputeDatasetView, EvaluationDatasetView
)
from model_store_interface.metadata.evaluation_configuration_meta import EvaluationConfigurationMeta
from model_store_interface.metadata.health_dcat_ap_dataset_meta import HealthDcatApDatasetMeta


class DatasetMeta(BaseModel):
    """Dataset metadata conforming to DCAT-AP JSON-LD profile (simplified runtime)."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    title: str = Field(..., description="Dataset title")
    version: str = Field(..., description="Dataset version")
    schema_version: str = Field(
        "dataset_meta_v1", description="Schema version for dataset_meta"
    )
    use_case: UseCase = Field(
        default=None,
        description="The specific clinical domain or use case (e.g., 'aml', 'scd') "
                    "to explicitly target validation plugins."
    )

    description: Optional[str] = Field(None, description="Dataset description")
    id: Optional[str] = Field(None, description="Dataset URI identifier")
    issued: Optional[str] = Field(None, description="ISO date when dataset was issued")

    context: Optional[str] = Field(None, alias="@context", description="Optional JSON-LD context URI or object")
    publisher: Optional[Dict[str, Any]] = Field(None, description="Publisher information")
    distributions: Optional[List[Dict[str, Any]]] = Field(
        None, description="Distribution descriptors (format, size, URL)"
    )

    omop_profile: Optional[str] = Field(
        None, description="OMOP CDM profile version if applicable"
    )
    preprocessing: Optional[Dict[str, Any]] = Field(
        None,
        description="Instructions or transformations applied to data during training."
    )
    evaluation: Optional[EvaluationConfigurationMeta] = Field(
        None,
        description="Configuration for utility and privacy evaluation."
    )
    publish_info: Optional[Dict[str, Any]] = Field(
        None,
        description="Metadata fields intended for dataset publication or catalogue upload."
    )
    variables: List[Variable] = Field(..., min_length=1, description="List of variable descriptors")

    meta_hash: Optional[str] = Field(
        None, pattern=r"^[a-fA-F0-9]{64}$", description="SHA256 hex of canonicalized meta (computed field)"
    )
    notes: Optional[str] = Field(None, description="Additional notes")

    @field_validator("meta_hash", mode="after")
    @classmethod
    def validate_meta_hash_format(cls, meta_hash: Optional[str]):
        """Validate meta_hash format if provided."""
        if meta_hash and not re.match(r"^[a-fA-F0-9]{64}$", meta_hash):
            raise ValueError("meta_hash must be a valid SHA256 hex string (64 characters)")
        return meta_hash

    @field_validator("variables", mode="after")
    @classmethod
    def validate_unique_variable_names(cls, variables: List[Variable]):
        """Ensure no duplicate variable names."""
        names = [v.name for v in variables]
        if len(names) != len(set(names)):
            duplicates = [n for n in names if names.count(n) > 1]
            raise ValueError(f"Duplicate variable names: {set(duplicates)}")
        return variables

    def project_for_compute(self) -> ComputeDatasetView:
        """Projects physical topology for preprocessing and training (Scenarios A, B, C)."""
        # Example DevSecOps filtering: Only pass variables that have a mapping or numeric type
        compute_vars = [v for v in self.variables if v.type in ("numeric", "integer", "categorical", "binary")]
        return ComputeDatasetView(
            use_case=self.use_case,
            compute_variables=compute_vars
        )

    def project_for_evaluation(self) -> EvaluationDatasetView:
        """Projects schema for utility and privacy evaluation plugins (Scenario D)."""
        return EvaluationDatasetView(
            use_case=self.use_case,
            evaluation_variables=self.variables
        )

    def _to_health_dcat_publisher(self) -> Optional[HealthDcatPublisher]:
        from model_store_interface.metadata.health_dcat_ap_dataset_meta import Publisher as HealthDcatPublisher

        if not isinstance(self.publisher, dict):
            return None

        name = self.publisher.get("name")
        mail = self.publisher.get("mbox") or self.publisher.get("mail")
        if not name or not mail:
            return None

        publisher_type = self.publisher.get("publisher_type", "Research Instituion")
        publisher_note = self.publisher.get("publisher_note") or self.publisher.get("note") or f"{self.title} publisher"

        try:
            return HealthDcatPublisher(
                name=name,
                mail=mail,
                publisher_type=publisher_type,
                publisher_note=publisher_note
            )
        except Exception:
            return None

    def _to_health_dcat_distributions(self) -> Optional[List[HealthDcatDistribution]]:
        from model_store_interface.metadata.health_dcat_ap_dataset_meta import \
            Distribution as HealthDcatDistribution

        if not self.distributions:
            return None

        distributions = []
        for dist in self.distributions:
            if not isinstance(dist, dict):
                continue
            distributions.append(
                HealthDcatDistribution(
                    title=dist.get("title", "distribution"),
                    description=dist.get("description"),
                    accessURL=dist.get("accessURL"),
                    byte_size=dist.get("byte_size") or dist.get("byteSize"),
                    format=dist.get("format"),
                    release_date=dist.get("release_date") or dist.get("releaseDate"),
                    modification_date=dist.get("modification_date") or dist.get("modificationDate")
                )
            )

        return distributions or None

    def _derive_health_categories(self) -> List[str]:
        if isinstance(self.publish_info, dict):
            health_category = self.publish_info.get("health_category")
            if isinstance(health_category, list) and health_category:
                return health_category

        return ["Electronic Health Records (EHR)"]

    def _convert_variable_to_health(self, variable: Variable) -> HealthDcatVariable:
        from model_store_interface.metadata.health_dcat_ap_dataset_meta import Variable as HealthDcatVariable

        type_mapping = {
            "numeric": "Decimal",
            "integer": "Integer",
            "categorical": "Categorical",
            "binary": "Binary",
            "datetime": "DateTime",
            "text": "Text"
        }
        datatype = type_mapping.get(variable.type, "String")

        mapping = None
        if variable.mapping:
            mapping = {str(k): str(v) for k, v in variable.mapping.items()}

        return HealthDcatVariable(
            name=variable.name,
            datatype=datatype,
            description=variable.description or variable.name,
            title_label=variable.name,
            unit=variable.unit,
            min=variable.min,
            max=variable.max,
            mean=variable.mean,
            median=variable.median,
            std=variable.std,
            categories=variable.categories,
            mapping=mapping,
            imputation=variable.imputation,
            missing_rate=variable.missing_rate,
            omop_concept_id=variable.omop_concept_id,
            radeep_term=variable.radeep_term,
            sensitivity=variable.sensitivity
        )

    def to_health_dcat_ap_dataset_meta(self) -> HealthDcatApDatasetMeta:
        """Convert the internal DatasetMeta to a publishable HealthDCAT-AP payload."""
        from model_store_interface.metadata.health_dcat_ap_dataset_meta import Creator, ContactPoint

        publisher = self._to_health_dcat_publisher()

        creators = None
        contact_points = None
        if isinstance(self.publish_info, dict):
            creator_data = self.publish_info.get("creator")
            if isinstance(creator_data, dict):
                creators = [Creator(
                    name=creator_data.get("name", self.publisher.get("name") if isinstance(self.publisher,
                                                                                           dict) else self.title),
                    url=creator_data.get("url"),
                    mail=creator_data.get("mail") or (
                        self.publisher.get("mbox") if isinstance(self.publisher, dict) else None)
                )]

            contact_data = self.publish_info.get("contact_point")
            if isinstance(contact_data, dict):
                contact_points = [ContactPoint(
                    name=contact_data.get("name", self.publisher.get("name") if isinstance(self.publisher,
                                                                                           dict) else self.title),
                    url=contact_data.get("url"),
                    mail=contact_data.get("mail"),
                    organisation_name=contact_data.get("organisation_name")
                )]

        return HealthDcatApDatasetMeta(
            context=self.context,
            title=self.title,
            acronym=self.publish_info.get("acronym") if isinstance(self.publish_info, dict) else None,
            keywords=self.publish_info.get("keywords") if isinstance(self.publish_info, dict) else None,
            description=self.description or "SYNTHEMA SDG Model",
            provenance=self.publish_info.get("provenance") if isinstance(self.publish_info, dict) else None,
            purpose=self.publish_info.get("purpose") if isinstance(self.publish_info, dict) else None,
            release_date=self.publish_info.get("release_date") if isinstance(self.publish_info, dict) else None,
            modification_date=self.publish_info.get("modification_date") if isinstance(self.publish_info,
                                                                                       dict) else None,
            population_coverage=self.publish_info.get("population_coverage") if isinstance(self.publish_info,
                                                                                           dict) else None,
            geographical_coverage=self.publish_info.get("geographical_coverage") if isinstance(self.publish_info,
                                                                                               dict) else None,
            language=self.publish_info.get("language") if isinstance(self.publish_info, dict) else None,
            publisher=publisher,
            creators=creators,
            contact_points=contact_points,
            version=self.version,
            schema_version=self.schema_version,
            theme=["Health"],
            applicable_legislation=self.publish_info.get("applicable_legislation") if isinstance(self.publish_info,
                                                                                                 dict) else None,
            health_category=self._derive_health_categories(),
            typical_age=None,
            number_of_records=self.publish_info.get("number_of_records") if isinstance(self.publish_info,
                                                                                       dict) else None,
            number_of_individuals=self.publish_info.get("number_of_individuals") if isinstance(self.publish_info,
                                                                                               dict) else None,
            distributions=self._to_health_dcat_distributions(),
            variables=[self._convert_variable_to_health(v) for v in self.variables if
                       getattr(v, "analysis_domain", "") != "internal_mlops"],
            notes=self.notes
        )

    def project_for_publish(self) -> HealthDcatApDatasetMeta:
        """Sanitises the payload for MLflow and the Data Catalogue (Scenario E)."""
        return self.to_health_dcat_ap_dataset_meta()

    def compute_hash(self) -> str:
        """Compute SHA256 digest of canonicalized metadata (excluding meta_hash field)."""
        data_for_hash = self.model_dump(exclude={"meta_hash"})
        canonical_json = json.dumps(data_for_hash, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        return hashlib.sha256(canonical_json.encode("utf-8")).hexdigest()

    def with_hash(self) -> "DatasetMeta":
        """Return a copy of this metadata with meta_hash computed."""
        return self.model_copy(update={"meta_hash": self.compute_hash()})

    def validate_hash(self) -> bool:
        """Check if computed hash matches stored meta_hash."""
        if not self.meta_hash:
            return True
        return self.compute_hash() == self.meta_hash

from enum import Enum
from typing import Optional, Dict, List, Literal

from pydantic import BaseModel, Field, field_validator, model_validator, ConfigDict


class UseCase(str, Enum):
    """Strict enumeration of supported clinical domains for MLOps tracking and validation."""

    AML = "AML"
    SCD = "SCD"
    AML_PUBLIC = "AML (public)"


class Variable(BaseModel):
    """Descriptor for a dataset variable/feature (DCAT-AP inspired)."""

    model_config = ConfigDict(extra="allow")

    name: str = Field(..., description="Variable name")
    type: Literal["numeric", "integer", "categorical", "binary", "datetime", "text"] = Field(
        ..., description="Variable type"
    )
    description: str = Field("", description="Variable description")
    analysis_domain: Literal["clinical", "genomic", "internal_mlops"] = Field(
        "clinical", description="Analysis domain"
    )
    unit: Optional[str] = Field(None, description="Unit of measurement")

    # Statistics for numeric
    min: Optional[float] = Field(None, description="Minimum value")
    max: Optional[float] = Field(None, description="Maximum value")
    mean: Optional[float] = Field(None, description="Mean value")
    median: Optional[float] = Field(None, description="Median value")
    std: Optional[float] = Field(None, description="Standard deviation")

    # For categorical/binary
    categories: Optional[List[str]] = Field(None, description="List of category values")
    mapping: Optional[Dict[str, int]] = Field(
        None, description="Mapping from category string to integer"
    )
    imputation: Optional[Literal["median", "mean", "mode", "none"]] = Field(
        None, description="Imputation strategy for missing values"
    )

    # Data quality
    missing_rate: Optional[float] = Field(
        None, ge=0.0, le=1.0, description="Proportion of missing values"
    )

    # Domain-specific
    omop_concept_id: Optional[str] = Field(None, description="OMOP concept identifier")
    radeep_term: Optional[str] = Field(None, description="Radeep terminology term")
    sensitivity: Optional[Literal["low", "medium", "high"]] = Field(
        None, description="Data sensitivity level"
    )

    @field_validator("mapping", mode="after")
    @classmethod
    def validate_mapping_values(cls, mapping: Optional[Dict[str, int]], info):
        """Ensure mapping values are unique integers."""
        if mapping:
            values = list(mapping.values())
            if not all(isinstance(v, int) for v in values):
                raise ValueError("All mapping values must be integers")
            if len(values) != len(set(values)):
                raise ValueError("Mapping values must be unique")
        return mapping

    @model_validator(mode="after")
    def validate_categories_mapping_consistency(self):
        """Ensure consistency between categories and mapping for categorical/binary variables."""
        if self.type in ["categorical", "binary"]:
            if not self.categories or not self.mapping:
                raise ValueError(
                    f"Variables of type '{self.type}' must have both 'categories' and 'mapping' defined"
                )
            if self.mapping:
                mapping_keys = set(self.mapping.keys())
                cat_set = set(str(c) for c in self.categories)
                if mapping_keys != cat_set:
                    missing_in_mapping = cat_set - mapping_keys
                    extra_in_mapping = mapping_keys - cat_set
                    msg = "Mapping keys must match categories exactly."
                    if missing_in_mapping:
                        msg += f" Missing in mapping: {missing_in_mapping}"
                    if extra_in_mapping:
                        msg += f" Extra in mapping: {extra_in_mapping}"
                    raise ValueError(msg)
        return self

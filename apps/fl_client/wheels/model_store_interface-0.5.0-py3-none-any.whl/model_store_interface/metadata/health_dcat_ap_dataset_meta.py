from __future__ import annotations

import hashlib
import json
from typing import Optional, Dict, List, Literal, Any, Union

from pydantic import BaseModel, Field, field_validator, ConfigDict, model_validator


class DatasetDiscovery(BaseModel):
    """Dataset discovery metadata."""

    model_config = ConfigDict(extra="allow")

    title: str = Field(..., description="A name given to the dataset")
    acronym: Optional[str] = Field(None, description="Alternative title/acronym")
    keywords: Optional[List[str]] = Field(None, description="Keywords/tags")
    description: str = Field(..., description="Free-text account of the dataset")
    provenance: Optional[str] = Field(None, description="Dataset lineage")
    purpose: Optional[str] = Field(None, description="Purpose of data processing")
    release_date: Optional[str] = Field(None, description="Release date")
    modification_date: Optional[str] = Field(None, description="Modification date")
    population_coverage: Optional[str] = Field(None, description="Population definition")
    geographical_coverage: Optional[str] = Field(None, description="Geographic coverage")
    language: Optional[str] = Field(None, description="Dataset language")


class Publisher(BaseModel):
    """Publisher information."""

    model_config = ConfigDict(extra="allow")

    name: str = Field(..., description="Publisher name")
    mail: str = Field(..., description="Publisher email")
    publisher_type: Literal[
        "National Statistics Institue",
        "Registry",
        "National Public Health Institute",
        "Biobank",
        "Research Instituion",
        "Hospital or Healthcare System",
        "Government Health Department",
        "Non-Governmental Organizations",
        "Pharmaceutical and Biomedical Company",
        "International Health Organization",
        "Health Insurance Company"
    ] = Field(..., description="Publisher type")
    publisher_note: str = Field(..., description="Publisher note")


class Creator(BaseModel):
    """Creator entity information."""

    model_config = ConfigDict(extra="allow")

    name: str = Field(..., description="Creator name")
    url: Optional[str] = Field(None, description="Creator URL")
    mail: Optional[str] = Field(None, description="Creator email")


class ContactPoint(BaseModel):
    """Contact point information."""

    model_config = ConfigDict(extra="forbid")

    name: str = Field(..., description="Contact name")
    url: Optional[str] = Field(None, description="Contact URL")
    mail: Optional[str] = Field(None, description="Contact email")
    organisation_name: Optional[str] = Field(None, description="Organisation name")


class Contacts(BaseModel):
    """Contact-related information."""

    model_config = ConfigDict(extra="allow")

    publisher: Publisher = Field(..., description="Publisher information")
    creators: Optional[List[Creator]] = Field(None, description="Creators")
    contact_points: Optional[List[ContactPoint]] = Field(None, description="Contact points")


class Documentation(BaseModel):
    """Documentation metadata."""

    model_config = ConfigDict(extra="allow")

    version: Optional[str] = Field(None, description="Version indicator")
    schema_version: Optional[str] = Field(None, description="Schema version")


class Categorisation(BaseModel):
    """Categorisation metadata."""

    model_config = ConfigDict(extra="forbid")

    theme: List[str] = Field(["Health"], description="Dataset theme")
    applicable_legislation: Optional[List[str]] = Field(None, description="Applicable legislation")
    health_category: List[str] = Field(
        ["Electronic Health Records (EHR)", "Human genetic, epigenomic and genomic data",
         "Data from medical registries and mortality registries"],
        description="Health category"
    )
    typical_age: Optional["TypicalAge"] = Field(None, description="Typical age range")
    number_of_records: Optional[int] = Field(None, description="Number of records")
    number_of_individuals: Optional[int] = Field(None, description="Number of individuals")

    @field_validator("applicable_legislation", mode="after")
    @classmethod
    def validate_applicable_legislation(cls, legislation: Optional[List[str]]):
        """Validate applicable legislation values."""
        if legislation:
            valid_values = ["EU Health Data Space Act", "High Value Dataset Act", "Data Governance Act"]
            for leg in legislation:
                if leg not in valid_values and not isinstance(leg, str):
                    raise ValueError(f"Invalid legislation: {leg}")
        return legislation


class TypicalAge(BaseModel):
    """Typical age range in years."""

    model_config = ConfigDict(extra="forbid")

    minimum_age: int = Field(..., ge=0, description="Minimum age in years")
    maximum_age: int = Field(..., ge=0, description="Maximum age in years")


class Distribution(BaseModel):
    """Distribution descriptor."""

    model_config = ConfigDict(extra="allow")

    title: str = Field(..., description="Distribution title")
    description: Optional[str] = Field(None, description="Distribution description")
    accessURL: Optional[str] = Field(None, description="Access URL")
    byte_size: Optional[float] = Field(None, description="Byte size")
    format: Optional[str] = Field(None, description="Format")
    release_date: Optional[str] = Field(None, description="Release date")
    modification_date: Optional[str] = Field(None, description="Modification date")


class Variable(BaseModel):
    """Descriptor for a dataset variable/feature (HealthDCAT-AP inspired)."""

    model_config = ConfigDict(extra="allow")

    name: str = Field(..., description="Variable name")
    datatype: Literal[
        "String", "Integer", "Decimal", "Boolean", "Number", "Float", "Date", "DateTime", "Categorical", "Binary",
        "Text"] = Field(
        ..., description="Variable datatype"
    )
    description: str = Field(..., description="Variable description")
    title_label: Optional[str] = Field(None, description="Human-readable title")
    unit: Optional[str] = Field(None, description="Unit of measurement")

    # Statistics for numeric
    min: Optional[float] = Field(None, description="Minimum value")
    max: Optional[float] = Field(None, description="Maximum value")
    mean: Optional[float] = Field(None, description="Mean value")
    median: Optional[float] = Field(None, description="Median value")
    std: Optional[float] = Field(None, description="Standard deviation")

    # For categorical/binary
    categories: Optional[List[str]] = Field(None, description="List of category values")
    mapping: Optional[Dict[str, str]] = Field(
        None, description="Mapping from category string to string code"
    )
    imputation: Optional[Literal["median", "mean", "mode", "none"]] = Field(
        None, description="Imputation strategy for missing values"
    )

    # Data quality
    missing_rate: Optional[float] = Field(
        None, ge=0.0, le=1.0, description="Proportion of missing values"
    )

    # Domain-specific
    omop_concept_id: Optional[str] = Field(None, description="OMOP concept identifier")
    radeep_term: Optional[str] = Field(None, description="Radeep terminology term")
    sensitivity: Optional[Literal["low", "medium", "high"]] = Field(
        None, description="Data sensitivity level"
    )

    @field_validator("mapping", mode="after")
    @classmethod
    def validate_mapping_values(cls, mapping: Optional[Dict[str, str]], info):
        """Ensure mapping values are strings if provided."""
        if mapping:
            values = list(mapping.values())
            if not all(isinstance(v, str) for v in values):
                raise ValueError("All mapping values must be strings")
        return mapping

    @model_validator(mode="after")
    def validate_categories_mapping_consistency(self):
        """Ensure consistency between categories and mapping for categorical/binary variables."""
        if self.datatype in ["Categorical", "Binary"]:
            if not self.categories or not self.mapping:
                raise ValueError(
                    f"Variables of type '{self.datatype}' must have both 'categories' and 'mapping' defined")
            if self.mapping:
                mapping_keys = set(self.mapping.keys())
                cat_set = set(str(c) for c in self.categories)
                if mapping_keys != cat_set:
                    missing_in_mapping = cat_set - mapping_keys
                    extra_in_mapping = mapping_keys - cat_set
                    msg = "Mapping keys must match categories exactly."
                    if missing_in_mapping:
                        msg += f" Missing in mapping: {missing_in_mapping}"
                    if extra_in_mapping:
                        msg += f" Extra in mapping: {extra_in_mapping}"
                    raise ValueError(msg)
        return self


class HealthDcatApDatasetMeta(BaseModel):
    """Dataset metadata conforming to HealthDCAT-AP JSON-LD profile (simplified runtime)."""

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    context: Optional[Union[str, Dict[str, Any]]] = Field(None, alias="@context",
                                                          description="Optional JSON-LD context URI or object")

    title: str = Field(..., description="A name given to the dataset")
    acronym: Optional[str] = Field(None, description="Alternative title of the dataset such as an acronym")
    keywords: Optional[List[str]] = Field(None, description="List of keywords or tags describing the dataset")
    description: str = Field(..., description="A free-text account of the dataset")
    provenance: Optional[str] = Field(None, description="A statement about the lineage of a dataset")
    purpose: Optional[str] = Field(None,
                                   description="A free text statement of the purpose of the processing of data or "
                                               "personal data")
    release_date: Optional[str] = Field(None, description="The date of formal issuance (date)")
    modification_date: Optional[str] = Field(None, description="The date of modification (date)")
    population_coverage: Optional[str] = Field(None, description="A definition of the population within the dataset")
    geographical_coverage: Optional[str] = Field(None, description="A geographic region that is covered by the dataset")
    language: Optional[str] = Field(None, description="A language of the dataset")

    publisher: Optional[Publisher] = Field(None, description="An entity responsible for making the dataset available")
    creators: Optional[List[Creator]] = Field(None, description="Entities responsible for producing the dataset")
    contact_points: Optional[List[ContactPoint]] = Field(None, description="Contact information for the dataset")

    version: str = Field(..., description="The version indicator (name or identifier) of a resource")
    schema_version: str = Field(..., description="Schema version of the meta file")

    theme: List[str] = Field(["Health"], description="A category of the Dataset (HealthDCAT)")
    applicable_legislation: Optional[List[str]] = Field(None,
                                                        description="The legislation that mandates the creation or "
                                                                    "management of the dataset")
    health_category: List[str] = Field(..., description="The health category to which this dataset belongs")

    typical_age: Optional[TypicalAge] = Field(None,
                                              description="The typical minimum and maximum age range (year) of the "
                                                          "population")
    number_of_records: Optional[int] = Field(None, description="Size of the dataset in terms of the number of records")
    number_of_individuals: Optional[int] = Field(None, description="Number of records for unique individuals")

    distributions: Optional[List[Distribution]] = Field(None, description="Distributions")
    variables: List[Variable] = Field(..., min_length=1, description="List of variable descriptors")

    notes: Optional[str] = Field(None, description="Additional notes")

    @field_validator("applicable_legislation", mode="after")
    @classmethod
    def validate_applicable_legislation(cls, legislation: Optional[List[str]]):
        if legislation:
            valid_values = ["EU Health Data Space Act", "High Value Dataset Act", "Data Governance Act"]
            for leg in legislation:
                if not isinstance(leg, str):
                    raise ValueError(f"Invalid legislation value: {leg}")
                if leg not in valid_values:
                    # allow arbitrary strings as schema permits anyOf string, but warn/raise only on non-strings
                    continue
        return legislation

    @field_validator("theme", mode="after")
    @classmethod
    def validate_theme(cls, theme: List[str]):
        if theme != ["Health"]:
            raise ValueError("theme must be exactly ['Health']")
        return theme

    @field_validator("health_category", mode="after")
    @classmethod
    def validate_health_category(cls, categories: List[str]):
        allowed = [
            "Electronic Health Records (EHR)",
            "Human genetic, epigenomic and genomic data",
            "Data from medical registries and mortality registries",
        ]
        for c in categories:
            if c not in allowed:
                raise ValueError(f"Invalid health_category value: {c}")
        return categories

    @field_validator("variables", mode="after")
    @classmethod
    def validate_unique_variable_names(cls, variables: List[Variable]):
        names = [v.name for v in variables]
        if len(names) != len(set(names)):
            duplicates = [n for n in names if names.count(n) > 1]
            raise ValueError(f"Duplicate variable names: {set(duplicates)}")
        return variables

    def compute_hash(self) -> str:
        """Compute SHA256 digest of canonicalized metadata."""
        data_for_hash = self.model_dump()
        canonical_json = json.dumps(data_for_hash, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        return hashlib.sha256(canonical_json.encode("utf-8")).hexdigest()

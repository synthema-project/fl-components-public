from __future__ import annotations

from typing import List, Optional, Dict, Any

from pydantic import BaseModel, ConfigDict

from model_store_interface.metadata.models.common import Variable, UseCase


class ComputeDatasetView(BaseModel):
    """
    Strictly typed, immutable projection for Scenarios A, B, & C.
    Used exclusively by the Local Learner for preprocessing, PyTorch/Keras
    tensor compilation, and training loop validation.
    """
    model_config = ConfigDict(frozen=True)

    use_case: UseCase
    compute_variables: List[Variable]
    # Future-proofing: Inject DP hyperparameters or preprocessing targets here
    preprocessing_rules: Optional[Dict[str, Any]] = None


class EvaluationDatasetView(BaseModel):
    """
    Strictly typed, immutable projection for Scenario D.
    Consumed by external clinical packages (e.g., aml-u, sba-priv).
    """
    model_config = ConfigDict(frozen=True)

    use_case: UseCase
    evaluation_variables: List[Variable]

from typing import Optional, List

from pydantic import BaseModel, Field, ConfigDict


class SurvivalEndpoint(BaseModel):
    """Survival endpoint definition."""

    model_config = ConfigDict(extra="forbid")

    name: str = Field(..., description="Human-readable endpoint name")
    time_column: str = Field(..., description="Column name containing the endpoint time value")
    event_column: str = Field(..., description="Column name containing the endpoint event indicator")
    stratification: str = Field(...,
                                description="Column that specifies the grouping variable for stratified survival "
                                            "curves")
    description: str = Field(..., description="Description of the survival endpoint")


class UtilityEvaluation(BaseModel):
    """Utility evaluation settings."""

    model_config = ConfigDict(extra="forbid")

    clinical_variables: List[str] = Field(..., description="Clinical variables used in utility evaluation")
    genomic_variables: List[str] = Field(..., description="Genomic variables used in utility evaluation")
    survival_endpoints: Optional[List[SurvivalEndpoint]] = Field(None,
                                                                 description="List of survival endpoint definitions")


class PrivacyEvaluation(BaseModel):
    """Privacy evaluation settings."""

    model_config = ConfigDict(extra="forbid")

    known_attributes: List[str] = Field(..., description="Attributes that are known or quasi-identifiers")
    sensitive_attributes: List[str] = Field(..., description="Attributes considered sensitive for privacy evaluation")
    differential_privacy: bool = Field(..., description="Flag indicating whether differential privacy is enabled")


class EvaluationConfigurationMeta(BaseModel):
    """Evaluation configuration metadata."""

    model_config = ConfigDict(extra="forbid")

    utility_evaluation: UtilityEvaluation = Field(..., description="Utility evaluation settings")
    privacy_evaluation: PrivacyEvaluation = Field(..., description="Privacy evaluation settings")

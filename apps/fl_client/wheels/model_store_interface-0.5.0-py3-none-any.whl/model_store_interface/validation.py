"""Validation module for synthetic data quality assessment."""
import importlib
import logging
from typing import Optional, Union, cast

from pandas import DataFrame

from model_store_interface.metadata.models.dataset_meta import DatasetMeta
from .validation_protocol import UtilityValidator, PrivacyValidator

logger = logging.getLogger(__name__)
NUMERIC_TYPE_NAMES = ('numeric', 'integer')


def _discover_plugin(group: str, dataset_meta: DatasetMeta) -> Optional[Union[UtilityValidator, PrivacyValidator]]:
    """
    Safely discovers and loads a validation plugin via Python entry points.
    Prevents arbitrary code execution by restricting resolution to registered packages.
    """
    # Access the string value of the Enum safely and deterministically
    use_case_str = dataset_meta.use_case.lower()

    try:
        entry_points = importlib.metadata.entry_points(group=group)

        # 1. First Pass: Attempt to load the explicitly defined domain plugin
        for ep in entry_points:
            if ep.name.lower() == use_case_str:
                logger.info(f"Loaded registered {group} plugin: {ep.name}")
                plugin = ep.load()

                # Cast the untyped dynamic load to our strict DevSecOps protocols
                return cast(Union[UtilityValidator, PrivacyValidator], plugin)

        # 2. Second Pass: Fallback to the default statistical plugin if explicitly registered
        for ep in entry_points:
            if ep.name.lower() == "default":
                logger.info(f"Loaded fallback {group} plugin: {ep.name}")
                plugin = ep.load()

                # Cast the untyped dynamic load to our strict DevSecOps protocols
                return cast(Union[UtilityValidator, PrivacyValidator], plugin)

    except Exception as exc:
        logger.warning(f"Failed to discover plugin for {group} / {use_case_str}: {exc}")

    return None


def _validate_report(
        synthetic_data: DataFrame,
        real_data: DataFrame,
        dataset_meta: DatasetMeta,
        node_id: Union[str, int],
        plugin_group: str,
        fallback_title: str
) -> str:
    """Executes the securely discovered plugin or gracefully degrades to the fallback report."""

    # The validator is now strictly typed as Union[UtilityValidator, PrivacyValidator]
    validator = _discover_plugin(plugin_group, dataset_meta)

    if validator is not None:
        try:
            logger.info(f"Executing external validation plugin for node {node_id}...")
            # mypy now mathematically guarantees these parameters match the Protocol
            evaluation_view = dataset_meta.project_for_evaluation()
            return validator(synthetic_data, real_data, evaluation_view)
        except Exception as e:
            logger.error(f"External validation plugin failed: {e}. Falling back to default metrics.")

    # Execute fallback logic if plugin is missing or fails
    metrics = _compute_default_metrics(synthetic_data, real_data, dataset_meta)
    return _generate_html_report(
        node_id=node_id,
        n_synthetic=len(synthetic_data),
        n_real=len(real_data),
        metrics=metrics,
        dataset_meta=dataset_meta,
        report_type=fallback_title
    )


def validate_utility_report(
        synthetic_data: DataFrame,
        real_data: DataFrame,
        dataset_meta: DatasetMeta,
        node_id: Union[str, int] = 0
) -> str:
    """Return a utility validation HTML report using the securely loaded plugin."""
    # The MLOps router inherently filters by use_case via the entry point name
    return _validate_report(
        synthetic_data, real_data, dataset_meta, node_id,
        "synthema.validation.utility", "Utility Fallback"
    )


def validate_privacy_report(
        synthetic_data: DataFrame,
        real_data: DataFrame,
        dataset_meta: DatasetMeta,
        node_id: Union[str, int] = 0
) -> str:
    """Return a privacy validation HTML report using the securely loaded plugin."""
    return _validate_report(
        synthetic_data, real_data, dataset_meta, node_id,
        "synthema.validation.privacy", "Privacy Fallback"
    )


def _compute_default_metrics(
        synthetic_data: DataFrame,
        real_data: DataFrame,
        dataset_meta: DatasetMeta
) -> dict:
    """
    Compute basic statistical metrics for validation.

    TODO: Replace with comprehensive validation from external libraries.
    """
    metrics = {'n_synthetic_samples': len(synthetic_data),
               'n_real_samples': len(real_data),
               'n_features': len(synthetic_data.columns)}

    global NUMERIC_TYPE_NAMES
    numeric_vars = [v.name for v in dataset_meta.variables if v.type in NUMERIC_TYPE_NAMES]

    for col in numeric_vars:
        if col in synthetic_data.columns and col in real_data.columns:
            metrics[f'{col}_synthetic_mean'] = float(synthetic_data[col].mean())
            metrics[f'{col}_real_mean'] = float(real_data[col].mean())
            metrics[f'{col}_synthetic_std'] = float(synthetic_data[col].std())
            metrics[f'{col}_real_std'] = float(real_data[col].std())

    return metrics


def _generate_html_report(
        node_id: str | int,
        n_synthetic: int,
        n_real: int,
        metrics: dict,
        dataset_meta: DatasetMeta,
        report_type: str = "Validation"
) -> str:
    """
    Generate a creative HTML report with statistics and visualizations.

    Args:
        node_id: Node identifier
        n_synthetic: Number of synthetic samples
        n_real: Number of real samples
        metrics: Computed validation metrics
        dataset_meta: Dataset metadata
        report_type: The type of report (e.g. 'Utility Fallback')

    Returns:
        str: HTML report
    """
    # Extract numeric variables for charting
    global NUMERIC_TYPE_NAMES
    numeric_vars = [v.name for v in dataset_meta.variables if v.type in NUMERIC_TYPE_NAMES]

    # Build chart data for mean comparison
    chart_bars = []
    for var in numeric_vars[:4]:  # Limit to first 4 numeric variables
        if f'{var}_synthetic_mean' in metrics and f'{var}_real_mean' in metrics:
            syn_mean = metrics[f'{var}_synthetic_mean']
            real_mean = metrics[f'{var}_real_mean']

            # Normalize for visualization (scale to 0-100)
            max_val = max(abs(syn_mean), abs(real_mean))
            if max_val > 0:
                syn_height = abs(syn_mean) / max_val * 100
                real_height = abs(real_mean) / max_val * 100
            else:
                syn_height = 0
                real_height = 0

            chart_bars.append({
                'var': var,
                'syn_height': syn_height,
                'real_height': real_height,
                'syn_val': syn_mean,
                'real_val': real_mean
            })

    # Generate chart HTML
    chart_html = ""
    for bar in chart_bars:
        chart_html += f"""
        <div class="chart-group">
            <div class="chart-label">{bar['var']}</div>
            <div class="chart-bars">
                <div class="bar-container">
                    <div class="bar synthetic" style="height: {bar['syn_height']}%"></div>
                    <div class="bar-label">Synthetic: {bar['syn_val']:.3f}</div>
                </div>
                <div class="bar-container">
                    <div class="bar real" style="height: {bar['real_height']}%"></div>
                    <div class="bar-label">Real: {bar['real_val']:.3f}</div>
                </div>
            </div>
        </div>
        """

    html = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Synthetic Data {report_type} Report - Node {node_id}</title>
        <style>
            body {{
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
                max-width: 1200px;
                margin: 0 auto;
                padding: 40px 20px;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: #333;
            }}
            .container {{
                background: white;
                border-radius: 16px;
                padding: 40px;
                box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            }}
            h1 {{
                color: #667eea;
                margin-top: 0;
                font-size: 2.5em;
                border-bottom: 3px solid #667eea;
                padding-bottom: 20px;
            }}
            h2 {{
                color: #764ba2;
                margin-top: 30px;
                font-size: 1.8em;
            }}
            .meta-info {{
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                gap: 20px;
                margin: 30px 0;
            }}
            .meta-card {{
                background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
                padding: 20px;
                border-radius: 12px;
                border-left: 4px solid #667eea;
            }}
            .meta-card h3 {{
                margin: 0 0 10px 0;
                color: #667eea;
                font-size: 0.9em;
                text-transform: uppercase;
                letter-spacing: 1px;
            }}
            .meta-card .value {{
                font-size: 2em;
                font-weight: bold;
                color: #333;
            }}
            .chart-section {{
                margin-top: 40px;
            }}
            .chart-group {{
                margin: 30px 0;
                padding: 20px;
                background: #f8f9fa;
                border-radius: 8px;
            }}
            .chart-label {{
                font-weight: bold;
                color: #667eea;
                margin-bottom: 15px;
                font-size: 1.2em;
            }}
            .chart-bars {{
                display: flex;
                gap: 40px;
                align-items: flex-end;
                height: 200px;
            }}
            .bar-container {{
                flex: 1;
                display: flex;
                flex-direction: column;
                align-items: center;
                gap: 10px;
            }}
            .bar {{
                width: 80px;
                min-height: 20px;
                border-radius: 4px 4px 0 0;
                transition: all 0.3s ease;
            }}
            .bar.synthetic {{
                background: linear-gradient(to top, #667eea, #764ba2);
            }}
            .bar.real {{
                background: linear-gradient(to top, #f093fb, #f5576c);
            }}
            .bar-label {{
                font-size: 0.9em;
                color: #666;
                text-align: center;
            }}
            .footer {{
                margin-top: 40px;
                padding-top: 20px;
                border-top: 2px solid #e0e0e0;
                color: #999;
                font-size: 0.9em;
                text-align: center;
            }}
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🔍 Synthetic Data {report_type} Report</h1>

            <div class="meta-info">
                <div class="meta-card">
                    <h3>Node ID</h3>
                    <div class="value">{node_id}</div>
                </div>
                <div class="meta-card">
                    <h3>Synthetic Samples</h3>
                    <div class="value">{n_synthetic:,}</div>
                </div>
                <div class="meta-card">
                    <h3>Real Test Samples</h3>
                    <div class="value">{n_real:,}</div>
                </div>
                <div class="meta-card">
                    <h3>Dataset</h3>
                    <div class="value" style="font-size: 1.2em;">{dataset_meta.title}</div>
                </div>
            </div>

            <h2>📊 Feature Comparison</h2>
            <div class="chart-section">
                {chart_html if chart_html else '<p>No numeric features to display.</p>'}
            </div>

            <div class="footer">
                <p>⚠️ This is a preliminary validation report. Full validation will be performed using external 
                validation libraries.</p>
                <p>Report generated by model-store-interface synthetic validation module</p>
            </div>
        </div>
    </body>
    </html>
    """

    return html

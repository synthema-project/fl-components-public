"""
Framework-agnostic Output Perturbation for Differential Privacy.

Adds calibrated Gaussian noise to a ``flwr.common.ParametersRecord`` before
parameters are transmitted to the server. This works with *any* model backend
(Scikit-Learn, custom NumPy, etc.) because it operates purely on serialised
parameter arrays — no training-time hooks are required.

Privacy accounting uses the analytic Gaussian mechanism formula:
    ε = sensitivity * sqrt(2 * ln(1.25 / δ)) / (noise_multiplier * sensitivity)
      = sqrt(2 * ln(1.25 / δ)) / noise_multiplier
"""

import math
from typing import Dict, Optional

import numpy as np

from .dp_wrappers import LocalDPWrapper


class OutputPerturbationDPWrapper(LocalDPWrapper):
    """Applies Gaussian Output Perturbation to ``flwr.common.ParametersRecord``.

    The wrapper is placed between the local learner and the server: after
    ``get_parameters()`` returns, the DP wrapper injects calibrated noise into
    every parameter array before they leave the node.

    Args:
        noise_multiplier: Ratio of noise std-dev to the L2 sensitivity (σ/Δf).
            Higher values provide stronger privacy at the cost of utility.
        target_delta: The δ for (ε, δ)-DP. Defaults to ``1e-5``.
        sensitivity: The L2 sensitivity of the function being perturbed.
            For output perturbation on normalised parameters, ``1.0`` is a
            common default; set it analytically when a tighter bound is known.
    """

    def __init__(
            self,
            noise_multiplier: float = 1.0,
            target_delta: float = 1e-5,
            sensitivity: float = 1.0,
    ) -> None:
        if noise_multiplier <= 0:
            raise ValueError("noise_multiplier must be positive.")
        if target_delta <= 0 or target_delta >= 1:
            raise ValueError("target_delta must be in (0, 1).")
        if sensitivity <= 0:
            raise ValueError("sensitivity must be positive.")

        self.noise_multiplier = noise_multiplier
        self.target_delta = target_delta
        self.sensitivity = sensitivity
        self._last_epsilon: Optional[float] = None

    # ------------------------------------------------------------------
    # LocalDPWrapper interface
    # ------------------------------------------------------------------

    # numpy dtype kind codes by family
    _FLOAT_KINDS = frozenset(("f",))  # float16/32/64/128
    _INT_KINDS = frozenset(("i", "u"))  # signed/unsigned integers (int8…int64, uint8…uint64)
    _BOOL_KIND = "b"  # numpy bool_

    def apply(self, parameters_record) -> object:
        """Inject Gaussian noise into every array in *parameters_record*.

        Noise is always generated in ``float64`` to prevent truncation, then
        the noisy result is mapped back to the original dtype family:

        * **Float** (``float16/32/64``): noise added in float64, result cast
          back to the original float dtype preserving precision tier.
        * **Integer / categorical** (``int8…int64``, ``uint8…uint64``): noise
          added in float64, result rounded to the nearest integer and clipped
          to the dtype's representable range before casting back.
        * **Boolean**: treated as ``{0, 1}`` float, noise added in float64,
          result rounded and clamped to ``{0, 1}`` then cast to ``bool``.

        All three families use the Gaussian mechanism, so the same analytic
        ε accounting applies across the entire record.

        Args:
            parameters_record: A ``flwr.common.ParametersRecord`` as returned
                by the local learner's ``get_parameters()``.

        Returns:
            A new ``flwr.common.ParametersRecord`` with perturbed values.

        Raises:
            TypeError: If any parameter array has an unsupported dtype kind
                (e.g. complex).  Float, integer, and boolean dtypes are
                supported.
        """
        import flwr  # flwr is a core MSI dependency — always available

        std_dev = self.noise_multiplier * self.sensitivity
        perturbed: dict = {}

        for key, array_obj in parameters_record.items():
            original = np.frombuffer(array_obj.data, dtype=array_obj.dtype).reshape(array_obj.shape)

            kind = original.dtype.kind

            if kind not in self._FLOAT_KINDS and kind not in self._INT_KINDS and kind != self._BOOL_KIND:
                raise TypeError(
                    f"OutputPerturbationDPWrapper does not support dtype '{original.dtype}' "
                    f"(kind '{kind}') for parameter '{key}'. "
                    "Supported kinds: float, integer (signed/unsigned), boolean."
                )

            # Always generate noise in float64 — avoids truncation for all families.
            noise = np.random.normal(loc=0.0, scale=std_dev, size=original.shape)
            noisy_f64 = original.astype(np.float64) + noise

            if kind in self._FLOAT_KINDS:
                # Cast back to the original float precision (float32 stays float32).
                noisy = noisy_f64.astype(original.dtype)

            elif kind in self._INT_KINDS:
                # Round to nearest integer and clip so the result fits the dtype.
                info = np.iinfo(original.dtype)
                noisy = np.clip(np.round(noisy_f64), info.min, info.max).astype(original.dtype)

            else:  # kind == self._BOOL_KIND
                # Booleans are 0/1; round and clamp so the result is still in {0, 1}.
                noisy = np.clip(np.round(noisy_f64), 0, 1).astype(original.dtype)

            perturbed[key] = flwr.common.Array(
                data=noisy.tobytes(),
                dtype=str(noisy.dtype),
                stype="numpy.ndarray.tobytes",
                shape=list(noisy.shape),
            )

        self._last_epsilon = self._compute_epsilon()
        return flwr.common.ParametersRecord(perturbed)

    def get_privacy_spent(self) -> Dict[str, float]:
        """Return the (ε, δ) cost of the last ``apply()`` call.

        ε is computed analytically from the Gaussian mechanism formula.
        If ``apply()`` has not yet been called, returns the pre-computed ε for
        the configured parameters.

        Returns:
            Dict with ``epsilon`` and ``delta`` keys.
        """
        epsilon = self._last_epsilon if self._last_epsilon is not None else self._compute_epsilon()
        return {"epsilon": round(epsilon, 6), "delta": self.target_delta}

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _compute_epsilon(self) -> float:
        """Compute ε using the analytic Gaussian mechanism formula.

        Formula: ε = sqrt(2 * ln(1.25 / δ)) / noise_multiplier
        (sensitivity cancels because noise_multiplier = σ / Δf)
        """
        return math.sqrt(2.0 * math.log(1.25 / self.target_delta)) / self.noise_multiplier

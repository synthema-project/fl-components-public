"""
Keras / TensorFlow Privacy DP-SGD wrapper.

Requires the optional ``tf-dp`` extra:
    pip install model-store-interface[tf-dp]
    # which pulls in: tensorflow>=2.13, tensorflow-privacy>=0.9

This wrapper must be used *inside* ``train_round()`` — it swaps the standard
Keras optimizer for a DP-aware counterpart so that per-example gradient
clipping and Gaussian noise injection happen during each ``model.fit()`` call.

Usage pattern inside a Keras local learner::

    def train_round(self, data, dataset_meta):
        dp_optimizer = self.dp_wrapper.apply(self.optimizer)
        self.model.compile(optimizer=dp_optimizer, loss=self.loss_fn, metrics=self.metrics)
        self.model.fit(dataset, epochs=self.epochs)
        return flwr.common.MetricsRecord(self.dp_wrapper.get_privacy_spent())
"""

from typing import Dict, Optional

from .dp_wrappers import LocalDPWrapper


class KerasDPWrapper(LocalDPWrapper):
    """Integrates TF-Privacy DP-SGD into a Keras training loop.

    Based on the original ``TensorflowDPWrapper`` design, adapted to the
    ``LocalDPWrapper`` interface. Maps a standard Keras optimizer to its
    DP-aware counterpart from ``tensorflow_privacy``, and computes
    cumulative (ε, δ) via ``compute_dp_sgd_privacy``.

    Args:
        noise_multiplier: Ratio of noise std-dev to the gradient clipping
            threshold. Higher values give stronger privacy.
        max_grad_norm: Per-example gradient clipping threshold (L2 norm clip).
            Defaults to ``1.0``.
        num_examples: Number of training examples (needed for accounting).
        batch_size: Mini-batch size (needed for accounting).
        target_delta: The δ for (ε, δ)-DP. Defaults to ``1/num_examples``.
    """

    def __init__(
            self,
            noise_multiplier: float,
            max_grad_norm: float,
            num_examples: int,
            batch_size: int,
            target_delta: Optional[float] = None,
    ) -> None:
        self.noise_multiplier = noise_multiplier
        self.max_grad_norm = max_grad_norm
        self.num_examples = num_examples
        self.batch_size = batch_size
        # Default delta: 1/n as recommended in the DP literature
        self.target_delta = target_delta if target_delta is not None else 1.0 / num_examples

        # Tracking: cumulative epochs across FL rounds for accounting
        self._total_epochs: float = 0.0

    def apply(self, optimizer):
        """Replace *optimizer* with a DP-aware Keras counterpart.

        Maps the standard optimizer type to its TF-Privacy DP equivalent.

        Args:
            optimizer: A ``tf.keras.optimizers.Optimizer`` instance
                (SGD, Adam, or Adagrad).

        Returns:
            A ``tensorflow_privacy`` DP optimizer with the same update rule.

        Raises:
            ImportError: If ``tensorflow`` or ``tensorflow_privacy`` are not installed.
            ValueError: If the optimizer type is not supported.
        """
        try:
            import tensorflow as tf
            from tensorflow_privacy.privacy.optimizers import dp_optimizer_keras
        except ImportError as exc:
            raise ImportError(
                "KerasDPWrapper requires tensorflow and tensorflow_privacy. "
                "Install them via: pip install model-store-interface[tf-dp]"
            ) from exc

        # Original optimizer → DP counterpart mapping (from original commented code)
        mapping_optimizers = {
            tf.keras.optimizers.SGD: dp_optimizer_keras.DPKerasSGDOptimizer,
            tf.keras.optimizers.Adam: dp_optimizer_keras.DPKerasAdamOptimizer,
            tf.keras.optimizers.Adagrad: dp_optimizer_keras.DPKerasAdagradOptimizer,
        }

        if type(optimizer) not in mapping_optimizers:
            raise ValueError(
                f"DP version not supported for optimizer '{type(optimizer).__name__}'. "
                f"Supported: {[cls.__name__ for cls in mapping_optimizers]}"
            )

        dp_cls = mapping_optimizers[type(optimizer)]
        dp_optimizer = dp_cls(
            l2_norm_clip=self.max_grad_norm,
            noise_multiplier=self.noise_multiplier,
            num_microbatches=self.batch_size,
            learning_rate=optimizer.learning_rate,
        )
        return dp_optimizer

    def record_epochs(self, local_epochs: int) -> None:
        """Accumulate the number of local epochs trained this FL round.

        Must be called after each ``model.fit()`` to keep accounting up to date::

            self.dp_wrapper.record_epochs(n_epochs)

        Args:
            local_epochs: Number of local epochs completed in the last round.
        """
        self._total_epochs += local_epochs

    def get_privacy_spent(self) -> Dict[str, float]:
        """Compute cumulative (ε, δ) using ``compute_dp_sgd_privacy``.

        Mirrors the accounting logic from the original commented implementation:
        tracks total epochs completed across all FL rounds and calls the
        TF-Privacy function once per query.

        Returns:
            Dict with ``epsilon`` and ``delta`` keys.

        Raises:
            ImportError: If ``tensorflow_privacy`` is not installed.
        """
        if self._total_epochs == 0:
            return {"epsilon": 0.0, "delta": self.target_delta}

        try:
            from tensorflow_privacy.privacy.analysis.compute_dp_sgd_privacy_lib import (
                compute_dp_sgd_privacy,
            )
        except ImportError as exc:
            raise ImportError(
                "KerasDPWrapper requires tensorflow_privacy. "
                "Install it via: pip install model-store-interface[tf-dp]"
            ) from exc

        epsilon, _ = compute_dp_sgd_privacy(
            n=self.num_examples,
            batch_size=self.batch_size,
            noise_multiplier=self.noise_multiplier,
            epochs=self._total_epochs,
            delta=self.target_delta,
        )
        return {"epsilon": round(float(epsilon), 6), "delta": self.target_delta}

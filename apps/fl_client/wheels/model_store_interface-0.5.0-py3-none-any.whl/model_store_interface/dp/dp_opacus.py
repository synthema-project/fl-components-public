"""
PyTorch / Opacus-based DP-SGD wrapper.

Requires the optional ``edge`` extra:
    pip install model-store-interface[edge]
    # which pulls in: torch==2.5.1, opacus>=1.5.0

This wrapper must be used *inside* ``train_round()`` — it wraps the model,
optimizer, and DataLoader with Opacus' PrivacyEngine so that per-sample
gradient clipping and noise injection happen during each backward pass.

Usage pattern inside a PyTorch local learner::

    def train_round(self, data, dataset_meta):
        model, optimizer, loader = self.dp_wrapper.apply(
            self.model, self.optimizer, self.train_loader
        )
        for batch in loader:
            ...
            loss.backward()
            optimizer.step()
        metrics = self.dp_wrapper.get_privacy_spent()
        ...
"""

import copy
from typing import Dict, Optional, Tuple

from .dp_wrappers import LocalDPWrapper


class OpacusDPWrapper(LocalDPWrapper):
    """Integrates Opacus DP-SGD into a PyTorch training loop.

    Wraps ``model``, ``optimizer``, and ``train_loader`` with an Opacus
    ``PrivacyEngine`` before each FL round so that all gradient updates
    satisfy (ε, δ)-DP via the RDP accountant.

    Supply *either* ``noise_multiplier`` *or* both ``target_epsilon`` and
    ``epochs``  — providing both or neither raises a ``ValueError``.

    Args:
        noise_multiplier: Fixed noise scale (σ / max_grad_norm). Mutually
            exclusive with ``target_epsilon``.
        target_epsilon: Desired ε for the whole training run. Opacus computes
            the noise multiplier automatically. Requires ``epochs``.
        epochs: Number of local training epochs per FL round. Required when
            ``target_epsilon`` is set.
        target_delta: The δ for (ε, δ)-DP. Defaults to ``1e-5``.
        max_grad_norm: Per-sample gradient clipping threshold. Defaults to ``1.0``.
    """

    def __init__(
            self,
            noise_multiplier: Optional[float] = None,
            target_epsilon: Optional[float] = None,
            epochs: Optional[int] = None,
            target_delta: float = 1e-5,
            max_grad_norm: float = 1.0,
    ) -> None:
        fixed_noise = noise_multiplier is not None
        epsilon_mode = target_epsilon is not None and epochs is not None
        if fixed_noise == epsilon_mode:
            raise ValueError(
                "Provide either `noise_multiplier` or both `target_epsilon` and `epochs`, "
                "but not both or neither."
            )

        self.noise_multiplier = noise_multiplier
        self.target_epsilon = target_epsilon
        self.epochs = epochs
        self.target_delta = target_delta
        self.max_grad_norm = max_grad_norm

        self._accountant = None
        self._privacy_engine = None

    # ------------------------------------------------------------------
    # Extension hook
    # ------------------------------------------------------------------

    def register_dp_hooks(self) -> None:
        """Register custom per-sample gradient samplers for non-standard layers.

        Override in a subclass when your model contains layers that Opacus does
        not support natively (e.g. custom attention, graph layers). By default
        this is a no-op.

        Example::

            from opacus.grad_sample import register_grad_sampler

            @register_grad_sampler(MyCustomLayer)
            def _sampler(layer, activations, backprops):
                ...
        """
        pass

    # ------------------------------------------------------------------
    # LocalDPWrapper interface
    # ------------------------------------------------------------------

    def apply(self, model, optimizer, train_loader) -> Tuple:
        """Attach Opacus PrivacyEngine to *model*, *optimizer*, and *train_loader*.

        Creates a deep copy of the model and optimizer state before wrapping
        so that the original objects are not mutated. A fresh ``PrivacyEngine``
        is constructed every FL round (Opacus engines are not serialisable).

        Args:
            model: A ``torch.nn.Module``.
            optimizer: A ``torch.optim.Optimizer``.
            train_loader: A ``torch.utils.data.DataLoader`` with ``drop_last=True``
                (required by Opacus for Poisson sub-sampling).

        Returns:
            Tuple ``(dp_model, dp_optimizer, dp_loader)`` ready for training.
        """
        try:
            from opacus import PrivacyEngine
        except ImportError as exc:
            raise ImportError(
                "OpacusDPWrapper requires opacus. "
                "Install it via: pip install model-store-interface[edge]"
            ) from exc

        self.register_dp_hooks()

        new_model = copy.deepcopy(model)
        new_model.load_state_dict(model.state_dict())

        cls_optimizer = type(optimizer)
        param_mapping = {old_p: new_p for old_p, new_p in zip(model.parameters(), new_model.parameters())}

        new_param_groups = []
        for group in optimizer.param_groups:
            new_group = {k: v for k, v in group.items() if k != "params"}
            new_group["params"] = [param_mapping[p] for p in group["params"]]
            new_param_groups.append(new_group)

        new_optimizer = cls_optimizer(new_param_groups, **optimizer.defaults)
        new_optimizer.load_state_dict(optimizer.state_dict())

        privacy_engine = PrivacyEngine(accountant="rdp")

        # Restore accountant state across rounds to accumulate ε correctly
        if self._accountant is not None:
            privacy_engine.accountant = self._accountant

        if self.noise_multiplier is None:
            model, optimizer, train_loader = privacy_engine.make_private_with_epsilon(
                module=new_model,
                grad_sample_mode="hooks",
                optimizer=new_optimizer,
                data_loader=train_loader,
                target_epsilon=self.target_epsilon,
                target_delta=self.target_delta,
                epochs=self.epochs,
                max_grad_norm=self.max_grad_norm,
            )
        else:
            model, optimizer, train_loader = privacy_engine.make_private(
                module=new_model,
                grad_sample_mode="hooks",
                optimizer=new_optimizer,
                data_loader=train_loader,
                noise_multiplier=self.noise_multiplier,
                max_grad_norm=self.max_grad_norm,
            )

        self._privacy_engine = privacy_engine
        return model, optimizer, train_loader

    def get_privacy_spent(self) -> Dict[str, float]:
        """Return cumulative (ε, δ) and snapshot accountant state for the next round.

        Must be called *after* the training loop completes each round.

        Returns:
            Dict with ``epsilon`` and ``delta`` keys.
        """
        if self._privacy_engine is not None:
            epsilon = self._privacy_engine.get_epsilon(self.target_delta)
            self._accountant = self._privacy_engine.accountant
            self._privacy_engine = None
            return {"epsilon": round(epsilon, 6), "delta": self.target_delta}
        return {"epsilon": 0.0, "delta": self.target_delta}

    # ------------------------------------------------------------------
    # Utility
    # ------------------------------------------------------------------

    @staticmethod
    def unwrap(model, optimizer) -> Tuple:
        """Unwrap Opacus ghost modules from *model* and *optimizer*.

        Call this after training to get back the original, serialisable objects
        before calling ``get_parameters()``.

        Args:
            model: The DP-wrapped model returned by ``apply()``.
            optimizer: The DP-wrapped optimizer returned by ``apply()``.

        Returns:
            Tuple ``(unwrapped_model, unwrapped_optimizer)``.
        """
        while hasattr(model, "_module") or hasattr(model, "module"):
            model = getattr(model, "_module", getattr(model, "module", model))

        while hasattr(optimizer, "original_optimizer") or hasattr(optimizer, "optimizer"):
            optimizer = getattr(optimizer, "original_optimizer", getattr(optimizer, "optimizer", optimizer))

        return model, optimizer

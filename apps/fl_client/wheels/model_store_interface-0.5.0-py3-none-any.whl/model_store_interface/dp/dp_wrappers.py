"""
Abstract base classes for integrating Differential Privacy (DP) into the federated learning workflow.

This module defines the shared interfaces for:
- Local DP mechanisms applied during or after training (``LocalDPWrapper``)
- Global privacy accounting at the aggregator level (``GlobalPrivacyAccountant``, ``FedAvgAccountant``)
"""

from abc import ABC, abstractmethod
from typing import Dict, Optional


# ---------------------------------------------------------------------------
# Aggregator-side DP accounting
# ---------------------------------------------------------------------------

class GlobalPrivacyAccountant(ABC):
    """Abstract base class for server-side privacy accountants.

    Aggregates per-node (ε, δ) budgets reported after each FL round
    and tracks the cumulative global privacy guarantee.
    """

    @abstractmethod
    def update(self, epsilons: list[float], deltas: list[float]) -> None:
        """Update the global privacy budget from per-node values.

        Args:
            epsilons: List of ε values, one per node.
            deltas: List of δ values, one per node.
        """
        pass

    @abstractmethod
    def get_privacy_spent(self) -> Dict[str, float]:
        """Return the current global (ε, δ) privacy cost.

        Returns:
            Dict with ``epsilon`` and ``delta`` keys.
        """
        pass


class FedAvgAccountant(GlobalPrivacyAccountant):
    """FedAvg-compatible privacy accountant.

    Under FedAvg composition, the global privacy guarantee equals the
    maximum per-node budget (parallel composition theorem).
    """

    def __init__(self) -> None:
        self.total_epsilon: float = 0.0
        self.total_delta: float = 0.0

    def update(self, epsilons: list[float], deltas: list[float]) -> None:
        """Set global budget as the max over all node budgets."""
        self.total_epsilon = max(epsilons)
        self.total_delta = max(deltas)

    def get_privacy_spent(self) -> Dict[str, float]:
        """Return ``{'epsilon': ..., 'delta': ...}`` for the global budget."""
        return {"epsilon": round(self.total_epsilon, 6), "delta": self.total_delta}


# ---------------------------------------------------------------------------
# Client-side local DP wrappers
# ---------------------------------------------------------------------------

class LocalDPWrapper(ABC):
    """Abstract base class for local Differential Privacy mechanisms.

    Concrete subclasses apply DP either during training (DP-SGD) or
    after training (output perturbation) and report the resulting budget.
    """

    @abstractmethod
    def apply(self, *args, **kwargs):
        """Apply the DP mechanism.

        Concrete implementations differ by backend:
        - Output perturbation wrappers accept a ``flwr.common.ParametersRecord``.
        - DP-SGD wrappers accept ``(model, optimizer, data_loader)``.
        """
        pass

    @abstractmethod
    def get_privacy_spent(self) -> Optional[Dict[str, float]]:
        """Return the (ε, δ) privacy cost of the last ``apply()`` call.

        Returns:
            Dict with ``epsilon`` and ``delta`` keys, or ``None`` if not yet applied.
        """
        pass

"""
Transparent DP decorator for any ``LLProtocol``-compliant local learner.

``DPLocalLearnerWrapper`` implements the full ``LLProtocol`` by delegation —
it forwards every method to the wrapped learner unchanged, *except*
``get_parameters()``, where it intercepts the outgoing parameters and passes
them through a ``LocalDPWrapper`` (typically ``OutputPerturbationDPWrapper``)
before they reach the server.

This means any existing or future SDG model can gain DP guarantees with a
single change in the factory function — the model class itself stays clean:

.. code-block:: python

    from model_store_interface import DPLocalLearnerWrapper, OutputPerturbationDPWrapper

    def create_local_learner():
        base = GMMSyntheticGenerator()          # plain, unmodified model
        dp   = OutputPerturbationDPWrapper(noise_multiplier=1.0)
        return DPLocalLearnerWrapper(base, dp)  # DP applied transparently

For DP-SGD backends (``OpacusDPWrapper``, ``KerasDPWrapper``) the learner's
``train_round()`` must still call ``dp_wrapper.apply()`` manually because those
mechanisms hook into the gradient computation — which the framework cannot
intercept from the outside.  In that case ``DPLocalLearnerWrapper`` still adds
value by exposing ``get_privacy_spent()`` on the wrapped object so the
simulation loop can collect the budget without knowing the backend.
"""

from typing import Dict, Optional

import flwr
from pandas import DataFrame

from .dp_wrappers import LocalDPWrapper
from model_store_interface.core.dataset_partition import DatasetPartition
from model_store_interface.metadata.models.dataset_meta import DatasetMeta


class DPLocalLearnerWrapper:
    """Decorates any ``LLProtocol`` learner with transparent DP.

    Intercepts ``get_parameters()`` to apply a ``LocalDPWrapper`` (e.g.
    ``OutputPerturbationDPWrapper``) before the parameters leave the node.
    All other ``LLProtocol`` methods are forwarded to the wrapped learner
    without modification.

    Args:
        learner: Any object conforming to ``LLProtocol``.
        dp_wrapper: A ``LocalDPWrapper`` instance that will process the
            parameters returned by ``learner.get_parameters()``.
    """

    def __init__(self, learner, dp_wrapper: LocalDPWrapper) -> None:
        self._learner = learner
        self._dp_wrapper = dp_wrapper

    # ------------------------------------------------------------------
    # LLProtocol delegation
    # ------------------------------------------------------------------

    def prepare_data(self, data: DataFrame, partition: DatasetPartition,
                     dataset_meta: DatasetMeta) -> DataFrame:
        """Delegate to the wrapped learner's ``prepare_data``."""
        return self._learner.prepare_data(data, partition, dataset_meta)

    def train_round(self, data: DataFrame, dataset_meta: DatasetMeta) -> flwr.common.MetricsRecord:
        """Delegate to the wrapped learner's ``train_round``."""
        return self._learner.train_round(data, dataset_meta)

    def get_parameters(self) -> flwr.common.ParametersRecord:
        """Get parameters from the learner and apply DP perturbation.

        The raw ``ParametersRecord`` is obtained from the wrapped learner
        and then passed through ``dp_wrapper.apply()`` before being returned.
        This is where Output Perturbation DP is applied transparently.

        Returns:
            A DP-perturbed ``flwr.common.ParametersRecord``.
        """
        raw_params = self._learner.get_parameters()
        return self._dp_wrapper.apply(raw_params)

    def set_parameters(self, parameters: flwr.common.ParametersRecord) -> None:
        """Delegate to the wrapped learner's ``set_parameters``."""
        self._learner.set_parameters(parameters)

    def evaluate(self, data: DataFrame, dataset_meta: DatasetMeta) -> flwr.common.MetricsRecord:
        """Delegate to the wrapped learner's ``evaluate``."""
        return self._learner.evaluate(data, dataset_meta)

    def generate_synthetic_data(self, n_samples: int, dataset_meta: DatasetMeta) -> DataFrame:
        """Delegate to the wrapped learner's ``generate_synthetic_data``."""
        return self._learner.generate_synthetic_data(n_samples, dataset_meta)

    # ------------------------------------------------------------------
    # DP-specific extension
    # ------------------------------------------------------------------

    def get_privacy_spent(self) -> Optional[Dict[str, float]]:
        """Return the (ε, δ) privacy cost from the DP wrapper.

        Returns:
            Dict with ``epsilon`` and ``delta`` keys.
        """
        return self._dp_wrapper.get_privacy_spent()

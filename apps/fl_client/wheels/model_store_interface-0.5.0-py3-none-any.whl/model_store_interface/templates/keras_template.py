import flwr
import numpy as np
import pandas as pd
from tensorflow import keras

from model_store_interface import DatasetPartition, DatasetMeta


def create_local_learner():
    class KerasLearner:
        def __init__(self):
            self.model = None
            self.decoder_model = None

        def prepare_data(self, data: pd.DataFrame, partition: DatasetPartition,
                         dataset_meta: DatasetMeta) -> pd.DataFrame:
            return data.fillna(0)

        def train_round(self, data: pd.DataFrame, dataset_meta: DatasetMeta) -> flwr.common.MetricsRecord:
            batch_size = 32

            input_dim = data.shape[1]
            latent_dim = 16

            if self.model is None:
                # Construct Autoencoder using Functional API
                inputs = keras.Input(shape=(input_dim,))
                encoded = keras.layers.Dense(latent_dim, activation='relu')(inputs)

                # Keep track of the decoder layer to reuse it during generation
                decoder_layer = keras.layers.Dense(input_dim)
                decoded = decoder_layer(encoded)

                self.model = keras.Model(inputs, decoded)

                # Isolate the decoder for the SDG generation step
                decoder_inputs = keras.Input(shape=(latent_dim,))
                self.decoder_model = keras.Model(decoder_inputs, decoder_layer(decoder_inputs))
                self.model.compile(optimizer='adam', loss='mse')

            history = self.model.fit(data.values, data.values, epochs=1, batch_size=batch_size, verbose=0)

            metrics = flwr.common.MetricsRecord({"loss": float(history.history['loss'][-1])})
            return metrics

        def get_parameters(self) -> flwr.common.ParametersRecord:
            # (Serialization logic here)
            return flwr.common.ParametersRecord()

        def set_parameters(self, parameters: flwr.common.ParametersRecord) -> None:
            pass

        def evaluate(self, data: pd.DataFrame, dataset_meta: DatasetMeta) -> flwr.common.MetricsRecord:
            if self.model is None:
                return flwr.common.MetricsRecord({"val_loss": 0.0})
            val_loss = self.model.evaluate(data.values, data.values, verbose=0)
            return flwr.common.MetricsRecord({"val_loss": float(val_loss)})

        def generate_synthetic_data(self, n_samples: int, dataset_meta: DatasetMeta) -> pd.DataFrame:
            if self.decoder_model is None:
                # Fallback if generation is called before training
                return pd.DataFrame(columns=[var.name for var in dataset_meta.variables])

            # Dynamically pull the latent dimension from the isolated decoder
            latent_dim = self.decoder_model.input_shape[1]
            random_latent_vectors = np.random.normal(size=(n_samples, latent_dim))

            # Pass the noise through the trained decoder
            synthetic_array = self.decoder_model.predict(random_latent_vectors, verbose=0)

            # Map the generated numpy array back to the expected DatasetMeta schema
            feature_names = [var.name for var in dataset_meta.variables]
            return pd.DataFrame(synthetic_array, columns=feature_names)

    return KerasLearner()


def create_aggregator():
    from model_store_interface import default_create_aggregator, FedAvgAccountant
    agg = default_create_aggregator()
    agg.accountant = FedAvgAccountant()
    return agg

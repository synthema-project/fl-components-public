import flwr
import pandas as pd
import torch
from torch import nn, optim
from torch.utils.data import DataLoader, TensorDataset

from model_store_interface import DatasetPartition, DatasetMeta


def create_local_learner():
    class Autoencoder(nn.Module):
        def __init__(self, input_dim):
            super().__init__()
            self.encoder = nn.Sequential(nn.Linear(input_dim, 16), nn.ReLU(), nn.Linear(16, 4))
            self.decoder = nn.Sequential(nn.Linear(4, 16), nn.ReLU(), nn.Linear(16, input_dim))

        def forward(self, x):
            return self.decoder(self.encoder(x))

    class PyTorchLearner:
        def __init__(self):
            self.model = None

        def prepare_data(self, data: pd.DataFrame, partition: DatasetPartition,
                         dataset_meta: DatasetMeta) -> pd.DataFrame:
            return data.fillna(0)  # Basic preprocessing

        def train_round(self, data: pd.DataFrame, dataset_meta: DatasetMeta) -> flwr.common.MetricsRecord:
            from model_store_interface.dp.dp_opacus import OpacusDPWrapper

            tensor_data = torch.tensor(data.values, dtype=torch.float32)
            dataset = TensorDataset(tensor_data, tensor_data)
            loader = DataLoader(dataset, batch_size=32, shuffle=True)

            if self.model is None:
                self.model = Autoencoder(input_dim=data.shape[len(dataset_meta.variables)])

            optimizer = optim.Adam(self.model.parameters(), lr=0.001)
            criterion = nn.MSELoss()

            # Wrap with Opacus
            dp_wrapper = OpacusDPWrapper(
                noise_multiplier=None,
                target_epsilon=None,
                epochs=None,
                target_delta=1e-5,
                max_grad_norm=1.0)

            # Opacus overrides the dataloader and optimizer
            self.model, optimizer, loader = dp_wrapper.apply(
                model=self.model,
                optimizer=optimizer,
                train_loader=loader
            )

            self.model.train()
            for x, y in loader:
                optimizer.zero_grad()
                loss = criterion(self.model(x), y)
                loss.backward()
                optimizer.step()

            metrics = flwr.common.MetricsRecord({"loss": float(loss.item())})
            # Pass the privacy budget back to the server
            for metric_name, val in dp_wrapper.get_privacy_spent():
                metrics[f"dp_{metric_name}"] = val
            return metrics

        def get_parameters(self) -> flwr.common.ParametersRecord:
            # Serialize state_dict
            pass

        def set_parameters(self, parameters: flwr.common.ParametersRecord) -> None:
            pass

        def evaluate(self, data: pd.DataFrame, dataset_meta: DatasetMeta) -> flwr.common.MetricsRecord:
            return flwr.common.MetricsRecord()

        def generate_synthetic_data(self, n_samples: int, dataset_meta: DatasetMeta) -> pd.DataFrame:
            # Generate synthetic data via Decoder sampling
            return pd.DataFrame()

    return PyTorchLearner()


# PyTorch DP requires a specific accountant on the aggregator
def create_aggregator():
    from model_store_interface import default_create_aggregator, FedAvgAccountant
    agg = default_create_aggregator()
    agg.accountant = FedAvgAccountant()
    return agg

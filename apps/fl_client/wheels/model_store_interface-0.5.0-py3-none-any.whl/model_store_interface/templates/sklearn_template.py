from collections import OrderedDict

import flwr
import pandas as pd
from sklearn.mixture import GaussianMixture

from model_store_interface import DatasetPartition, DatasetMeta


def create_local_learner():
    class GMMLearner:
        def __init__(self):
            self.model = GaussianMixture(n_components=3, covariance_type='full')
            self.is_fitted = False

        def prepare_data(self, data: pd.DataFrame, partition: DatasetPartition,
                         dataset_meta: DatasetMeta) -> pd.DataFrame:
            return data.fillna(0)  # Basic preprocessing

        def train_round(self, data: pd.DataFrame, dataset_meta: DatasetMeta) -> flwr.common.MetricsRecord:
            self.model.fit(data)
            self.is_fitted = True
            return flwr.common.MetricsRecord({"log_likelihood": self.model.score(data)})

        def get_parameters(self) -> flwr.common.ParametersRecord:
            if not self.is_fitted:
                return flwr.common.ParametersRecord()

            # Serialize GMM parameters (weights, means, covariances)
            params = OrderedDict()
            params["weights"] = flwr.common.Array(data=self.model.weights_.tobytes(),
                                                  dtype=str(self.model.weights_.dtype), stype="numpy.ndarray.tobytes",
                                                  shape=list(self.model.weights_.shape))
            params["means"] = flwr.common.Array(data=self.model.means_.tobytes(), dtype=str(self.model.means_.dtype),
                                                stype="numpy.ndarray.tobytes", shape=list(self.model.means_.shape))
            params["covariances"] = flwr.common.Array(data=self.model.covariances_.tobytes(),
                                                      dtype=str(self.model.covariances_.dtype),
                                                      stype="numpy.ndarray.tobytes",
                                                      shape=list(self.model.covariances_.shape))
            return flwr.common.ParametersRecord(params)

        def set_parameters(self, parameters: flwr.common.ParametersRecord) -> None:
            # Deserialization logic here
            pass

        def evaluate(self, data: pd.DataFrame, dataset_meta: DatasetMeta) -> flwr.common.MetricsRecord:
            return flwr.common.MetricsRecord({"val_log_likelihood": self.model.score(data) if self.is_fitted else 0.0})

        def generate_synthetic_data(self, n_samples: int, dataset_meta: DatasetMeta) -> pd.DataFrame:
            samples, _ = self.model.sample(n_samples)
            return pd.DataFrame(samples, columns=[var.name for var in dataset_meta.variables])

    return GMMLearner()


def create_aggregator():
    from model_store_interface import default_create_aggregator
    return default_create_aggregator()

from typing import Protocol, runtime_checkable

from pandas import DataFrame

from model_store_interface.metadata.dataset_views import EvaluationDatasetView


@runtime_checkable
class UtilityValidator(Protocol):
    """
    Formal interface for external utility validation packages (e.g., aml-u, scd-u).
    Guarantees the plugin accepts the generated synthetic pool, the real hold-out
    partition, and the DCAT-AP schema to produce an HTML report string.
    """

    def __call__(self, synthetic_data: DataFrame, real_data: DataFrame,
                 dataset_meta: EvaluationDatasetView) -> str:
        ...


@runtime_checkable
class PrivacyValidator(Protocol):
    """
    Formal interface for external privacy validation packages (e.g., sba-priv).
    Guarantees the plugin assesses the generated synthetic pool against the
    real hold-out partition and returns an HTML report string.
    """

    def __call__(self, synthetic_data: DataFrame, real_data: DataFrame,
                 dataset_meta: EvaluationDatasetView) -> str:
        ...

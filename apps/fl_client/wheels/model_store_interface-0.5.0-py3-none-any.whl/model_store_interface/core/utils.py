import json
from collections import OrderedDict
from datetime import datetime
from typing import Optional, Dict, List, Any

import flwr
import numpy as np
import pandas as pd

from model_store_interface.metadata.models.dataset_meta import DatasetMeta, Variable


class Utils:
    @staticmethod
    def _basic_array_deserialisation(array: flwr.common.Array) -> flwr.common.NDArray:
        return np.frombuffer(buffer=array.data, dtype=array.dtype).reshape(array.shape)

    @staticmethod
    def parameters_to_dict(params_record: flwr.common.ParametersRecord) -> OrderedDict:
        state_dict = OrderedDict()
        for k, v in params_record.items():
            state_dict[k] = Utils._basic_array_deserialisation(v)

        return state_dict

    @staticmethod
    def _ndarray_to_array(ndarray: flwr.common.NDArray) -> flwr.common.Array:
        """Represent NumPy ndarray as Array."""
        return flwr.common.Array(
            data=ndarray.tobytes(),
            dtype=str(ndarray.dtype),
            stype="numpy.ndarray.tobytes",
            shape=list(ndarray.shape),
        )

    @staticmethod
    def dict_to_parameter_record(
            parameters: OrderedDict["str", flwr.common.NDArray],
    ) -> flwr.common.ParametersRecord:
        state_dict = OrderedDict()
        for k, v in parameters.items():
            state_dict[k] = Utils._ndarray_to_array(v)

        return flwr.common.ParametersRecord(state_dict)

    @staticmethod
    def pytorch_to_parameter_record(
            state_dict: dict,
    ) -> flwr.common.ParametersRecord:
        """Serialise your PyTorch model."""
        transformed_state_dict = OrderedDict()

        for k, v in state_dict.items():
            transformed_state_dict[k] = Utils._ndarray_to_array(v.numpy())

        return flwr.common.ParametersRecord(transformed_state_dict)

    @staticmethod
    def parameters_to_pytorch_state_dict(
            params_record: flwr.common.ParametersRecord,
    ) -> dict:
        # Make sure to import locally torch as it is only available in the server
        import torch

        """Reconstruct PyTorch state_dict from its serialised representation."""
        state_dict = {}
        for k, v in params_record.items():
            state_dict[k] = torch.tensor(Utils._basic_array_deserialisation(v))

        return state_dict


# --------------------------
# dataset_meta helpers (Pydantic-based)
# --------------------------

def load_meta_from_path(path: str) -> DatasetMeta:
    """Load and parse DatasetMeta from a JSON or JSON-LD file."""
    with open(path, "r", encoding="utf-8") as fh:
        data = json.load(fh)
    return DatasetMeta(**data)


def infer_dataset_meta(
        df: pd.DataFrame,
        title: Optional[str] = None,
        version: Optional[str] = None,
        hints: Optional[Dict[str, Dict[str, Any]]] = None,
) -> DatasetMeta:
    """
    Infer a DatasetMeta from a pandas DataFrame.
    
    - Categories mapping generated deterministically: by frequency desc, then lexicographic.
    - Mapping values are integers 0..K-1.
    - Returns a validated Pydantic DatasetMeta with computed meta_hash.
    """
    if hints is None:
        hints = {}

    variables_list: List[Variable] = []

    for col in df.columns:
        col_series = df[col]
        var_hint = hints.get(col, {})

        # Determine type
        if var_hint.get("type"):
            vtype = var_hint["type"]
        else:
            if pd.api.types.is_integer_dtype(col_series.dropna()):
                vtype = "integer"
            elif pd.api.types.is_bool_dtype(col_series.dropna()):
                vtype = "binary"
            elif pd.api.types.is_numeric_dtype(col_series.dropna()):
                vtype = "numeric"
            elif pd.api.types.is_datetime64_any_dtype(col_series.dropna()):
                vtype = "datetime"
            elif pd.api.types.is_bool_dtype(col_series.dropna()):
                vtype = "binary"
            else:
                nunique = col_series.dropna().nunique()
                if nunique > 0 and nunique <= min(50, max(2, int(len(df) * 0.05))):
                    vtype = "categorical"
                else:
                    vtype = "text"

        var_data: Dict[str, Any] = {
            "name": col,
            "type": vtype,
            "description": var_hint.get("description", f"Inferred variable: {col}"),
            "analysis_domain": var_hint.get("analysis_domain", "clinical"),
        }

        # Statistics
        try:
            nonnull = col_series.dropna()

            if vtype in ("numeric", "integer"):
                if len(nonnull) > 0:
                    var_data["min"] = float(nonnull.min())
                    var_data["max"] = float(nonnull.max())
                    var_data["mean"] = float(nonnull.mean())
                    var_data["median"] = float(nonnull.median())
                    var_data["std"] = float(nonnull.std() if len(nonnull) > 1 else 0.0)

            if vtype in ("categorical", "binary"):
                counts = nonnull.astype(str).value_counts()
                cats = list(counts.index)
                cats_sorted = sorted(cats, key=lambda x: (-int(counts.get(x, 0)), str(x)))
                var_data["categories"] = cats_sorted
                mapping = {str(cat): i for i, cat in enumerate(cats_sorted)}
                var_data["mapping"] = mapping

            var_data["missing_rate"] = float(col_series.isna().mean())
        except Exception:
            var_data["missing_rate"] = float(col_series.isna().mean())

        # Merge hints
        var_data.update(var_hint)

        variables_list.append(Variable(**var_data))

    meta = DatasetMeta(
        title=title or "inferred_dataset",
        version=version or datetime.utcnow().isoformat(),
        schema_version="dataset_meta_v1",
        variables=variables_list,
    )

    return meta.with_hash()

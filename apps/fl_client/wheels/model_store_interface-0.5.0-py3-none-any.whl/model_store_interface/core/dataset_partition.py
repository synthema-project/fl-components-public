from enum import StrEnum


class DatasetPartition(StrEnum):
    """Enumeration of dataset partitions."""

    TRAIN = "train"
    VAL = "val"
    TEST = "test"

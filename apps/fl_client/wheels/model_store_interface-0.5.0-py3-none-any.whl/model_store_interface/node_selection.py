"""Node selection strategies for synthetic data generation."""
import random
from typing import Sequence, TypeVar

# Define a generic type variable
T = TypeVar("T")


def select_random_node(node_ids: Sequence[T]) -> T:
    """
    Randomly selects a node from the available nodes.

    Args:
        node_ids: A sequence of available node IDs (e.g., list or tuple)

    Returns:
        T: The selected node ID, matching the type of the input sequence elements.

    Raises:
        ValueError: If node_ids is empty
    """
    if not node_ids:
        raise ValueError("Cannot select from empty node list")
    return random.choice(node_ids)


def select_first_node(node_ids: Sequence[T]) -> T:
    """
    Selects the first node from the available nodes.

    Args:
        node_ids: A sequence of available node IDs (e.g., list or tuple)

    Returns:
        T: The first node ID in the sequence, matching the input type.

    Raises:
        ValueError: If node_ids is empty
    """
    if not node_ids:
        raise ValueError("Cannot select from empty node list")
    return node_ids[0]

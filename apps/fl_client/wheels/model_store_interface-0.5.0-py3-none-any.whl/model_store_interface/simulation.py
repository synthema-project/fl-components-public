import os
from typing import Any, Dict, List, Optional, Tuple, Literal

import pandas as pd

from .local_file_publisher import LocalFilePublisher
from .node_selection import select_random_node
from .core.dataset_partition import DatasetPartition
from model_store_interface.metadata.models.dataset_meta import DatasetMeta
from .validation import validate_privacy_report, validate_utility_report

NodePartitions = Dict[int, Dict[DatasetPartition, pd.DataFrame]]


def _partition_data(data: pd.DataFrame, n_nodes: int, random_state: int = 42) -> NodePartitions:
    """
    Partition data into n_nodes.
    Each node partition is further split into:
    - 60% train
    - 20% val
    - 20% test
    """
    # First, shuffle the data to ensure random partitioning
    if n_nodes > len(data):
        raise ValueError("There are more nodes than data samples, therefore cannot split samples into nodes")
    shuffled_data = data.sample(frac=1.0, random_state=random_state).reset_index(drop=True)

    # Split evenly into n_nodes chunks
    node_chunks = []
    chunk_size = len(shuffled_data) // n_nodes
    for i in range(n_nodes):
        start_idx = i * chunk_size
        # For the last node, include any remaining rows
        end_idx = (i + 1) * chunk_size if i < n_nodes - 1 else len(shuffled_data)
        node_chunks.append(shuffled_data.iloc[start_idx:end_idx].reset_index(drop=True))

    partitions = {}
    for node_id, chunk in enumerate(node_chunks):
        n_rows = len(chunk)
        train_end = int(0.6 * n_rows)
        val_end = train_end + int(0.2 * n_rows)

        df_train = chunk.iloc[:train_end].reset_index(drop=True)
        df_val = chunk.iloc[train_end:val_end].reset_index(drop=True)
        df_test = chunk.iloc[val_end:].reset_index(drop=True)

        partitions[node_id] = {
            DatasetPartition.TRAIN: df_train,
            DatasetPartition.VAL: df_val,
            DatasetPartition.TEST: df_test
        }

    return partitions


def _normalize_partition_dict(partitions: dict) -> Dict[DatasetPartition, pd.DataFrame]:
    normalized: Dict[DatasetPartition, pd.DataFrame] = {}
    unknown_keys: List[Any] = []

    for raw_key, frame in partitions.items():
        if isinstance(raw_key, DatasetPartition):
            key = raw_key
        elif isinstance(raw_key, str):
            normalized_key = raw_key.lower()
            if normalized_key in {"train", "training"}:
                key = DatasetPartition.TRAIN
            elif normalized_key in {"val", "validation"}:
                key = DatasetPartition.VAL
            elif normalized_key in {"test", "testing"}:
                key = DatasetPartition.TEST
            else:
                unknown_keys.append(raw_key)
                continue
        else:
            unknown_keys.append(raw_key)
            continue

        normalized[key] = frame

    if unknown_keys:
        raise ValueError(
            f"Unknown partition keys found: {unknown_keys}. "
            f"Expected train/val/test keys or DatasetPartition values."
        )

    return normalized


def _normalize_node_partitions(node_partitions: dict) -> NodePartitions:
    normalized: NodePartitions = {}
    for raw_node_id, partitions in node_partitions.items():
        if isinstance(raw_node_id, str) and raw_node_id.isdigit():
            node_id = int(raw_node_id)
        else:
            node_id = raw_node_id

        if not isinstance(node_id, int):
            raise ValueError("Node identifiers in node_partitions must be integers or numeric strings")
        if not isinstance(partitions, dict):
            raise ValueError("Each node partition entry must be a dictionary of train/val/test splits")

        normalized[node_id] = _normalize_partition_dict(partitions)
    return normalized


def _validate_node_partitions(node_partitions: NodePartitions, n_nodes: int) -> None:
    if len(node_partitions) != n_nodes:
        raise ValueError("node_partitions must include exactly one entry per node")

    required = {DatasetPartition.TRAIN, DatasetPartition.VAL, DatasetPartition.TEST}
    for node_id, parts in node_partitions.items():
        if set(parts.keys()) != required:
            raise ValueError(
                f"Node {node_id} partitions must include train, val, and test splits. "
                f"Found: {sorted(str(k) for k in parts.keys())}"
            )

        for split_key in required:
            split = parts[split_key]
            if not isinstance(split, pd.DataFrame):
                raise ValueError(
                    f"Node {node_id} partition '{split_key}' must be a pandas DataFrame, "
                    f"got {type(split).__name__}"
                )
            if split.empty:
                raise ValueError(
                    f"Node {node_id} partition '{split_key}' is empty. "
                    f"Each train/val/test split must contain at least one row."
                )

    expected_nodes = set(range(n_nodes))
    if set(node_partitions.keys()) != expected_nodes:
        raise ValueError("node_partitions keys must be contiguous node indices from 0 to n_nodes - 1")


def _collect_privacy_budgets(local_learners: Dict[int, Any]) -> Optional[Dict[str, float]]:
    """Collect per-node privacy budgets if learners expose ``get_privacy_spent()``.

    Returns the aggregated global (ε, δ) via ``FedAvgAccountant``, or ``None``
    if none of the learners implement the DP interface.

    Args:
        local_learners: Dict of local learner instances keyed by node_id.

    Returns:
        Dict with ``epsilon`` and ``delta`` keys, or ``None``.
    """
    from model_store_interface.dp.dp_wrappers import FedAvgAccountant

    budgets = [
        learner.get_privacy_spent()
        for learner in local_learners.values()
        if callable(getattr(learner, "get_privacy_spent", None))
    ]

    if not budgets:
        return None

    accountant = FedAvgAccountant()
    accountant.update(
        epsilons=[b["epsilon"] for b in budgets],
        deltas=[b["delta"] for b in budgets],
    )
    return accountant.get_privacy_spent()


def _run_fl_loop(
        federated_model,
        node_partitions: NodePartitions,
        n_rounds: int,
        dataset_meta: DatasetMeta
) -> Tuple[Dict[int, Any], Any]:
    """Run federated learning loop over the virtual node partitions."""
    local_learners = {node_id: federated_model.create_local_learner() for node_id in node_partitions.keys()}
    aggregator = federated_model.create_aggregator()

    # prepare data on each learner for all partitions (TRAIN, VAL, TEST)
    prepared_node_data: Dict[int, Dict[DatasetPartition, pd.DataFrame]] = {}
    for node_id, learner in local_learners.items():
        prepared_node_data[node_id] = {}
        for split in DatasetPartition:
            if split in node_partitions[node_id]:
                prepared_node_data[node_id][split] = learner.prepare_data(
                    node_partitions[node_id][split],
                    split,
                    dataset_meta
                )

    for r in range(1, n_rounds + 1):
        collected_params = []
        for node_id, learner in local_learners.items():
            # train round using preprocessed TRAIN split
            learner.train_round(prepared_node_data[node_id][DatasetPartition.TRAIN], dataset_meta)
            # get parameters (DP noise applied transparently if wrapped)
            params = learner.get_parameters()
            collected_params.append(params)

        # aggregate parameters
        aggregated_params = aggregator.aggregate_parameters(collected_params)

        # distribute parameters back to all learners
        for learner in local_learners.values():
            learner.set_parameters(aggregated_params)

        # Evaluate the updated global model on each node's local validation split
        collected_eval_metrics = []
        for node_id, learner in local_learners.items():
            if DatasetPartition.VAL in prepared_node_data[node_id]:
                eval_metrics = learner.evaluate(prepared_node_data[node_id][DatasetPartition.VAL], dataset_meta)
                collected_eval_metrics.append(eval_metrics)

        # Aggregate the distributed validation metrics centrally on the coordinator node
        if collected_eval_metrics:
            global_metrics = aggregator.aggregate_metrics(collected_eval_metrics)
            print(f"[Round {r}] Centralized Global Validation Metrics: {dict(global_metrics.items())}")

    return local_learners, aggregator


def _run_flower_simulation(
        model: Any,
        node_partitions: NodePartitions,
        n_rounds: int,
        dataset_meta: DatasetMeta,
        n_samples: int
) -> Tuple[pd.DataFrame, Dict[int, str], Dict[int, str], Optional[Dict[str, float]]]:
    """Run a Flower-based federated simulation in separate actors.

    Optimized using Ray's Shared Memory Object Store to pass zero-copy dataset references
    between Virtual Clients, avoiding massive JSON serialization bottlenecks.
    """
    import pickle
    import time
    import random
    import flwr as fl
    import ray  # Leveraged directly from the active Ray simulation cluster
    from flwr.client import ClientApp
    from flwr.server import ServerApp
    from flwr.common import Context, Message, RecordSet, ConfigsRecord, MessageType
    from flwr.server import Driver

    client_app = ClientApp()

    @client_app.query()
    def client_query(msg: Message, ctx: Context) -> Message:
        configs = msg.content.configs_records
        if "init_config" in configs:
            init_rec = configs["init_config"]
            client_id = int(init_rec["client_id"])

            # PERFORMANCE RESOLUTION: Reconstruct references from binary IDs and fetch directly from Ray Object Store
            train_ref = ray.ObjectRef(init_rec["train_ref_bin"])
            val_ref = ray.ObjectRef(init_rec["val_ref_bin"])
            test_ref = ray.ObjectRef(init_rec["test_ref_bin"])

            train_df = ray.get(train_ref)
            val_df = ray.get(val_ref)
            test_df = ray.get(test_ref)

            meta = DatasetMeta.model_validate_json(str(init_rec["dataset_meta_json"]))

            model_inst = pickle.loads(bytes.fromhex(str(init_rec["model_hex"])))
            learner = model_inst.create_local_learner()

            raw_parts = {
                DatasetPartition.TRAIN: train_df,
                DatasetPartition.VAL: val_df,
                DatasetPartition.TEST: test_df,
            }

            prepared = {}
            for split in DatasetPartition:
                prepared[split] = learner.prepare_data(
                    data=raw_parts[split],
                    partition=split,
                    dataset_meta=meta
                )

            ctx.state.local_learner = learner
            ctx.state.prepared_data = prepared
            ctx.state.dataset_meta = meta
            ctx.state.client_id = client_id
            return msg.create_reply(RecordSet())

        elif "generate_config" in configs:
            gen_config = configs["generate_config"]
            samples_to_gen = int(gen_config.get("n_samples", n_samples))

            if "final_model" in msg.content.parameters_records:
                ctx.state.local_learner.set_parameters(msg.content.parameters_records["final_model"])

            synthetic_df = ctx.state.local_learner.generate_synthetic_data(
                samples_to_gen, ctx.state.dataset_meta
            )

            # PERFORMANCE RESOLUTION: Put generated DataFrame straight into Ray, passing only the reference binary ID
            synthetic_ref = ray.put(synthetic_df)

            reply_rec = RecordSet()
            reply_rec.configs_records["synthetic_data_ref"] = ConfigsRecord({
                "bin_id": synthetic_ref.binary_id()
            })
            return msg.create_reply(reply_rec)

        elif "validate_config" in configs:
            client_id = ctx.state.client_id

            # PERFORMANCE RESOLUTION: Fetch broadcasted synthetic dataset reference instantly from Ray
            synthetic_ref_bin = msg.content.configs_records["synthetic_data_ref"]["bin_id"]
            synthetic_ref = ray.ObjectRef(synthetic_ref_bin)
            synthetic_df = ray.get(synthetic_ref)

            real_test = ctx.state.prepared_data[DatasetPartition.TEST]
            html_util = validate_utility_report(
                synthetic_data=synthetic_df,
                real_data=real_test,
                dataset_meta=ctx.state.dataset_meta,
                node_id=client_id
            )
            html_priv = validate_privacy_report(
                synthetic_data=synthetic_df,
                real_data=real_test,
                dataset_meta=ctx.state.dataset_meta,
                node_id=client_id
            )

            configs_payload = {
                "html_utility": html_util,
                "html_privacy": html_priv
            }

            learner = ctx.state.local_learner
            if callable(getattr(learner, "get_privacy_spent", None)):
                spent = learner.get_privacy_spent()
                configs_payload["privacy_epsilon"] = float(spent["epsilon"])
                configs_payload["privacy_delta"] = float(spent["delta"])

            reply_rec = RecordSet()
            reply_rec.configs_records["validation_report"] = ConfigsRecord(configs_payload)
            return msg.create_reply(reply_rec)
        else:
            raise ValueError("Unknown query action")

    @client_app.train()
    def client_train(msg: Message, ctx: Context) -> Message:
        params = msg.content.parameters_records["fancy_model"]
        learner = ctx.state.local_learner
        learner.set_parameters(params)

        train_df = ctx.state.prepared_data[DatasetPartition.TRAIN]
        metrics = learner.train_round(data=train_df, dataset_meta=ctx.state.dataset_meta)

        reply_rec = RecordSet()
        reply_rec.parameters_records["fancy_model_returned"] = learner.get_parameters()
        reply_rec.metrics_records["train_metrics"] = metrics
        return msg.create_reply(reply_rec)

    @client_app.evaluate()
    def client_eval(msg: Message, ctx: Context) -> Message:
        params = msg.content.parameters_records["fancy_model"]
        learner = ctx.state.local_learner
        learner.set_parameters(params)

        val_df = ctx.state.prepared_data[DatasetPartition.VAL]
        metrics = learner.evaluate(data=val_df, dataset_meta=ctx.state.dataset_meta)

        reply_rec = RecordSet()
        reply_rec.metrics_records["eval_metrics"] = metrics
        return msg.create_reply(reply_rec)

    server_app = ServerApp()
    results_holder: Dict[str, Any] = {}

    def _wait_for_replies(driver: Driver, msg_ids: List[str]) -> List[Message]:
        msg_ids_set = set(msg_ids)
        replies_dict = {}
        while len(replies_dict) < len(msg_ids_set):
            pulled = driver.pull_messages(message_ids=list(msg_ids_set - set(replies_dict.keys())))
            for r in pulled:
                if r.has_content():
                    replies_dict[r.reply_to_message_id] = r
            if len(replies_dict) < len(msg_ids_set):
                time.sleep(0.1)
        return [replies_dict[mid] for mid in msg_ids]

    @server_app.main()
    def server_main(driver: Driver, context: Context) -> None:
        node_ids = driver.get_node_ids()

        # Construct explicit, O(1) tracking dictionary mapping hash tokens to partition keys
        partition_keys = sorted(list(node_partitions.keys()))
        node_id_to_partition = {node_id: partition_keys[i] for i, node_id in enumerate(node_ids)}

        # Phase 1: setup/init
        messages = []
        for node_id in node_ids:
            rec = RecordSet()
            p_key = node_id_to_partition[node_id]
            node_part = node_partitions[p_key]

            # Put DataFrames directly into Ray and pass binary ObjectRef IDs
            train_ref = ray.put(node_part[DatasetPartition.TRAIN])
            val_ref = ray.put(node_part[DatasetPartition.VAL])
            test_ref = ray.put(node_part[DatasetPartition.TEST])

            configs = {
                "client_id": p_key,
                "num_clients": len(node_ids),
                "train_ref_bin": train_ref.binary_id(),
                "val_ref_bin": val_ref.binary_id(),
                "test_ref_bin": test_ref.binary_id(),
                "dataset_meta_json": dataset_meta.model_dump_json(),
                "model_hex": pickle.dumps(model).hex()
            }
            rec.configs_records["init_config"] = ConfigsRecord(configs)

            msg = driver.create_message(
                content=rec,
                message_type=MessageType.QUERY,
                dst_node_id=node_id,
                group_id="init",
                ttl=120
            )
            messages.append(msg)

        m_ids = driver.push_messages(messages)
        m_ids = [mid for mid in m_ids if mid != ""]
        _wait_for_replies(driver, m_ids)

        # FL Rounds
        global_model = model.create_local_learner()
        aggregator = model.create_aggregator()

        for r in range(n_rounds):
            # Train
            train_messages = []
            for node_id in node_ids:
                rec = RecordSet()
                rec.parameters_records["fancy_model"] = global_model.get_parameters()
                msg = driver.create_message(
                    content=rec,
                    message_type=MessageType.TRAIN,
                    dst_node_id=node_id,
                    group_id=f"train_{r}",
                    ttl=120
                )
                train_messages.append(msg)
            m_ids = driver.push_messages(train_messages)
            m_ids = [mid for mid in m_ids if mid != ""]
            replies = _wait_for_replies(driver, m_ids)

            param_records = [reply.content.parameters_records["fancy_model_returned"] for reply in replies]
            new_params = aggregator.aggregate_parameters(param_records)
            global_model.set_parameters(new_params)

            # Eval
            eval_messages = []
            for node_id in node_ids:
                rec = RecordSet()
                rec.parameters_records["fancy_model"] = global_model.get_parameters()
                msg = driver.create_message(
                    content=rec,
                    message_type=MessageType.EVALUATE,
                    dst_node_id=node_id,
                    group_id=f"eval_{r}",
                    ttl=120
                )
                eval_messages.append(msg)
            m_ids = driver.push_messages(eval_messages)
            m_ids = [mid for mid in m_ids if mid != ""]
            replies = _wait_for_replies(driver, m_ids)

            metrics_records = [reply.content.metrics_records["eval_metrics"] for reply in replies]
            global_metrics = aggregator.aggregate_metrics(metrics_records)
            print(f"[Round {r + 1}] Centralized Global Validation Metrics: {dict(global_metrics.items())}")

        # Gen synthetic data
        generator_node_id = random.choice(node_ids)
        gen_rec = RecordSet()
        gen_rec.configs_records["generate_config"] = ConfigsRecord({"n_samples": n_samples})
        gen_rec.parameters_records["final_model"] = global_model.get_parameters()

        gen_msg = driver.create_message(
            content=gen_rec,
            message_type=MessageType.QUERY,
            dst_node_id=generator_node_id,
            group_id="generate",
            ttl=120
        )
        m_ids = driver.push_messages([gen_msg])
        m_ids = [mid for mid in m_ids if mid != ""]
        replies = _wait_for_replies(driver, m_ids)

        # PERFORMANCE RESOLUTION: Fetch synthetic data reference and resolve directly from Ray
        synthetic_ref_bin = replies[0].content.configs_records["synthetic_data_ref"]["bin_id"]
        synthetic_ref = ray.ObjectRef(synthetic_ref_bin)
        synthetic_df = ray.get(synthetic_ref)

        # Broadcast val
        val_messages = []
        for node_id in node_ids:
            val_rec = RecordSet()
            val_rec.configs_records["validate_config"] = ConfigsRecord({})
            # PERFORMANCE RESOLUTION: Broadcast lightweight Ray reference binary ID instead of massive JSON
            val_rec.configs_records["synthetic_data_ref"] = ConfigsRecord({
                "bin_id": synthetic_ref_bin
            })
            msg = driver.create_message(
                content=val_rec,
                message_type=MessageType.QUERY,
                dst_node_id=node_id,
                group_id="validate",
                ttl=120
            )
            val_messages.append(msg)

        m_ids = driver.push_messages(val_messages)
        m_ids = [mid for mid in m_ids if mid != ""]
        replies = _wait_for_replies(driver, m_ids)

        utility_reports = {}
        privacy_reports = {}
        budgets = []
        for reply in replies:
            # PERFORMANCE ALIGNMENT: O(1) pre-computed dict lookup replaces unstable O(n) .index scans
            client_id = node_id_to_partition[reply.src_node_id]
            report_payload = reply.content.configs_records["validation_report"]
            utility_reports[client_id] = str(report_payload["html_utility"])
            privacy_reports[client_id] = str(report_payload["html_privacy"])
            if "privacy_epsilon" in report_payload:
                budgets.append({
                    "epsilon": float(report_payload["privacy_epsilon"]),
                    "delta": float(report_payload["privacy_delta"])
                })

        # Store results
        results_holder["synthetic_data"] = synthetic_df
        results_holder["utility_reports"] = utility_reports
        results_holder["privacy_reports"] = privacy_reports
        results_holder["privacy_budget"] = None

        if budgets:
            from model_store_interface.dp.dp_wrappers import FedAvgAccountant
            accountant = FedAvgAccountant()
            accountant.update(
                epsilons=[b["epsilon"] for b in budgets],
                deltas=[b["delta"] for b in budgets],
            )
            results_holder["privacy_budget"] = accountant.get_privacy_spent()

    # Run Simulation
    fl.simulation.run_simulation(
        server_app=server_app,
        client_app=client_app,
        num_supernodes=len(node_partitions),
        backend_config={"ray_config": {"include_dashboard": False}}
    )

    return (
        results_holder["synthetic_data"],
        results_holder["utility_reports"],
        results_holder["privacy_reports"],
        results_holder["privacy_budget"]
    )


def run_local_simulation(
        model: Any,
        data: pd.DataFrame,
        dataset_meta: DatasetMeta,
        n_nodes: int,
        n_rounds: int,
        output_dir: str,
        n_samples: int = 1000,
        node_partitions: Optional[dict] = None,
        partition_random_state: int = 42,
        mode: Literal["loop", "flower"] = "loop"
) -> dict:
    """Run a full local simulation of federated learning, including validation and result publishing.

    If the local learners expose ``get_privacy_spent()`` (e.g. when wrapped with
    ``DPLocalLearnerWrapper``), the aggregated global (ε, δ) budget is collected
    automatically and included in the result dict under the ``"privacy_budget"`` key.
    Non-DP models are not affected.
    """
    # 1. Partition data
    if node_partitions is None:
        node_partitions = _partition_data(data, n_nodes, random_state=partition_random_state)
    else:
        node_partitions = _normalize_node_partitions(node_partitions)
        _validate_node_partitions(node_partitions, n_nodes)

    if mode == "flower":
        synthetic_data, utility_reports, privacy_reports, privacy_budget = _run_flower_simulation(
            model=model,
            node_partitions=node_partitions,
            n_rounds=n_rounds,
            dataset_meta=dataset_meta,
            n_samples=n_samples
        )
    else:
        # 2. Run FL training
        local_learners, aggregator = _run_fl_loop(model, node_partitions, n_rounds, dataset_meta)

        # 3. Collect privacy budgets from DP-aware learners (no-op for plain learners)
        privacy_budget = _collect_privacy_budgets(local_learners)

        # 4. Generate synthetic data using random node's learner
        node_ids = list(node_partitions.keys())
        generator_node_id = select_random_node(node_ids)
        generator_node = local_learners[generator_node_id]
        synthetic_data = generator_node.generate_synthetic_data(n_samples, dataset_meta)

        # 5. Perform validation per node (comparing synthetic data vs node's holdout partition)
        utility_reports = {}
        privacy_reports = {}
        for node_id in range(n_nodes):
            real_holdout = node_partitions[node_id][DatasetPartition.TEST]
            utility_reports[node_id] = validate_utility_report(
                synthetic_data=synthetic_data,
                real_data=real_holdout,
                dataset_meta=dataset_meta,
                node_id=node_id,
            )
            privacy_reports[node_id] = validate_privacy_report(
                synthetic_data=synthetic_data,
                real_data=real_holdout,
                dataset_meta=dataset_meta,
                node_id=node_id,
            )

    # 6. Publish outputs to output_dir
    publisher = LocalFilePublisher()
    publisher.publish(
        synthetic_data=synthetic_data,
        dataset_meta=dataset_meta,
        utility_reports=utility_reports,
        privacy_reports=privacy_reports,
        output_dir=output_dir
    )

    # Return summary dict
    result = {
        "status": "success",
        "n_nodes": n_nodes,
        "n_rounds": n_rounds,
        "n_samples": n_samples,
        "output_dir": output_dir,
        "utility_reports": utility_reports,
        "privacy_reports": privacy_reports,
        "synthetic_data": synthetic_data,
        "synthetic_data_path": os.path.join(output_dir, "synthetic_data.csv"),
        "metadata_path": os.path.join(output_dir, "dataset_meta_filtered.json"),
    }
    if privacy_budget is not None:
        result["privacy_budget"] = privacy_budget
    return result

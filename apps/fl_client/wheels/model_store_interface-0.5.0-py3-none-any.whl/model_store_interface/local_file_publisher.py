import json
import os
from typing import Dict, Union

import pandas as pd

from model_store_interface.metadata.models.dataset_meta import DatasetMeta


class LocalFilePublisher:
    """Internal publisher to write simulation outputs and HTML validation reports to disk."""

    def _filter_metadata(self, dataset_meta: DatasetMeta) -> dict:
        """Filter dataset metadata for publication by using the publish-time projection."""
        publish_view = dataset_meta.project_for_publish()
        return publish_view.model_dump(exclude_none=True, by_alias=True)

    def publish(
            self,
            synthetic_data: pd.DataFrame,
            dataset_meta: DatasetMeta,
            utility_reports: Dict[Union[str, int], str],
            privacy_reports: Dict[Union[str, int], str],
            output_dir: str
    ) -> None:
        """
        Write synthetic data, filtered metadata, and validation HTML reports to the specified directory.

        Args:
            synthetic_data: Pandas DataFrame containing the synthetic data.
            dataset_meta: The dataset metadata.
            utility_reports: Dictionary mapping node_id to utility HTML report string.
            privacy_reports: Dictionary mapping node_id to privacy HTML report string.
            output_dir: The directory to write the files to.
        """
        os.makedirs(output_dir, exist_ok=True)

        # Write synthetic data
        synthetic_data_path = os.path.join(output_dir, "synthetic_data.csv")
        synthetic_data.to_csv(synthetic_data_path, index=False)

        # Write filtered metadata
        metadata_path = os.path.join(output_dir, "dataset_meta_filtered.json")
        filtered_meta = self._filter_metadata(dataset_meta)
        with open(metadata_path, "w", encoding="utf-8") as f:
            json.dump(filtered_meta, f, indent=4, ensure_ascii=False)

        # Write utility reports
        for node_id, html_content in utility_reports.items():
            utility_path = os.path.join(output_dir, f"report_node_{node_id}_utility.html")
            with open(utility_path, "w", encoding="utf-8") as f:
                f.write(html_content)

        # Write privacy reports
        for node_id, html_content in privacy_reports.items():
            privacy_path = os.path.join(output_dir, f"report_node_{node_id}_privacy.html")
            with open(privacy_path, "w", encoding="utf-8") as f:
                f.write(html_content)

import os


def get_main_template():
    current_dir = os.path.dirname(__file__)
    template_path = os.path.join(current_dir, os.path.join("templates", 'example_template.py'))
    with open(template_path, 'r', encoding='utf-8') as file:
        return file.read()


def get_readme_template():
    current_dir = os.path.dirname(__file__)
    template_path = os.path.join(current_dir, os.path.join("templates", 'readme_template.md'))
    with open(template_path, 'r', encoding='utf-8') as file:
        return file.read()


def get_pyproject_template():
    current_dir = os.path.dirname(__file__)
    template_path = os.path.join(current_dir, os.path.join("templates", 'pyproject_template.toml'))
    with open(template_path, 'r', encoding='utf-8') as file:
        return file.read()


def get_license_template():
    current_dir = os.path.dirname(__file__)
    template_path = os.path.join(current_dir, os.path.join("templates", 'license_template.txt'))
    with open(template_path, 'r', encoding='utf-8') as file:
        return file.read()


def get_pytorch_template(dp: bool) -> str:
    filename = 'pytorch_dp_template.py' if dp else 'pytorch_template.py'
    return _read_template(filename)


def get_keras_template(dp: bool) -> str:
    filename = 'keras_dp_template.py' if dp else 'keras_template.py'
    return _read_template(filename)


def get_sklearn_template(dp: bool) -> str:
    filename = 'sklearn_dp_template.py' if dp else 'sklearn_template.py'
    return _read_template(filename)


def _read_template(filename: str) -> str:
    current_dir = os.path.dirname(__file__)
    template_path = os.path.join(current_dir, "templates", filename)
    with open(template_path, 'r', encoding='utf-8') as file:
        return file.read()
